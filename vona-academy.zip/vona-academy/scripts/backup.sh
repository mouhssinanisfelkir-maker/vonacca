#!/usr/bin/env bash
# Sauvegarde la base PostgreSQL et les vidéos dans le dossier indiqué (défaut : ./backups).
# Usage : ./scripts/backup.sh [dossier]
set -euo pipefail
cd "$(dirname "$0")/.."

DEST="${1:-./backups}"
STAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$DEST"
DEST_ABS=$(cd "$DEST" && pwd)

echo "Sauvegarde de la base de données..."
docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB"' | gzip > "$DEST_ABS/db-$STAMP.sql.gz"

echo "Sauvegarde des vidéos..."
docker compose run --rm --no-deps --user root -v "$DEST_ABS":/backup backend \
  sh -c "tar czf /backup/videos-$STAMP.tgz -C /data/videos ."

echo "Terminé : $DEST_ABS/db-$STAMP.sql.gz et $DEST_ABS/videos-$STAMP.tgz"
