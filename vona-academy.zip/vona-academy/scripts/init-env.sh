#!/usr/bin/env bash
# Génère un fichier .env avec des secrets aléatoires.
set -euo pipefail
cd "$(dirname "$0")/.."

if [ -f .env ]; then
  echo "Le fichier .env existe déjà : rien n'a été modifié." >&2
  exit 1
fi

rand() { head -c 64 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c "$1"; }

DB_PASSWORD=$(rand 24)
JWT=$(rand 64)
ADMIN_PASSWORD="Vona-$(rand 10)"

sed \
  -e "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=${DB_PASSWORD}|" \
  -e "s|^JWT_SECRET=.*|JWT_SECRET=${JWT}|" \
  -e "s|^ADMIN_PASSWORD=.*|ADMIN_PASSWORD=${ADMIN_PASSWORD}|" \
  .env.example > .env
chmod 600 .env

echo "Fichier .env créé."
echo "Compte administrateur : $(grep '^ADMIN_EMAIL=' .env | cut -d= -f2)"
echo "Mot de passe initial  : ${ADMIN_PASSWORD}  (à changer à la première connexion)"
