import cookieParser from 'cookie-parser';
import express from 'express';
import { config } from './config';
import { errorHandler } from './errors';
import { initDatabase } from './schema';
import authRoutes from './routes/auth';
import courseRoutes from './routes/courses';
import learnRoutes from './routes/learn';
import lessonRoutes from './routes/lessons';
import statsRoutes from './routes/stats';
import userRoutes from './routes/users';

async function main() {
  await initDatabase();

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1); // derrière le reverse proxy Nginx
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'same-origin');
    next();
  });
  app.use(express.json({ limit: '2mb' }));
  app.use(cookieParser());

  app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));
  app.use('/api/auth', authRoutes);
  app.use('/api/users', userRoutes);
  app.use('/api/courses', courseRoutes);
  app.use('/api/lessons', lessonRoutes);
  app.use('/api/learn', learnRoutes);
  app.use('/api/stats', statsRoutes);
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Route introuvable.' }));
  app.use(errorHandler);

  const server = app.listen(config.port, () => console.log(`API Vona Academy démarrée sur le port ${config.port}`));
  // Les envois de vidéos volumineux peuvent dépasser les 5 minutes par défaut de Node
  server.requestTimeout = 0;
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
