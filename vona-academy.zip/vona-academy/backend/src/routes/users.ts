import bcrypt from 'bcryptjs';
import { Router } from 'express';
import { z } from 'zod';
import { authenticate, requireRole } from '../auth';
import { q } from '../db';
import { HttpError, h } from '../errors';
import { generatePassword, idParam, publicUser } from '../util';

const router = Router();
router.use(authenticate, requireRole('ADMIN', 'RH'));

const email = z.string().trim().toLowerCase().email('Adresse e-mail invalide.');
const name = (label: string) => z.string().trim().min(1, `${label} obligatoire.`).max(100);
const department = z
  .string()
  .trim()
  .max(100)
  .nullish()
  .transform((v) => v || null);
const role = z.enum(['ADMIN', 'RH', 'LEARNER']);

// L'admin voit tous les comptes ; les RH ne gèrent que les apprenants.
router.get(
  '/',
  h(async (req, res) => {
    const rows =
      req.user!.role === 'ADMIN'
        ? await q('SELECT * FROM users ORDER BY last_name, first_name')
        : await q("SELECT * FROM users WHERE role = 'LEARNER' ORDER BY last_name, first_name");
    res.json(rows.map(publicUser));
  }),
);

const createSchema = z.object({
  email,
  firstName: name('Prénom'),
  lastName: name('Nom'),
  department,
  role: role.default('LEARNER'),
  password: z.string().min(8, 'Le mot de passe doit contenir au moins 8 caractères.').max(128).optional(),
});

router.post(
  '/',
  h(async (req, res) => {
    const b = createSchema.parse(req.body);
    if (req.user!.role !== 'ADMIN' && b.role !== 'LEARNER') {
      throw new HttpError(403, 'Seul un administrateur peut créer ce type de compte.');
    }
    const password = b.password ?? generatePassword();
    const hash = await bcrypt.hash(password, 10);
    const inserted = await q(
      `INSERT INTO users (email, first_name, last_name, department, role, password_hash, must_change_password)
       VALUES ($1, $2, $3, $4, $5, $6, TRUE)
       ON CONFLICT (email) DO NOTHING
       RETURNING *`,
      [b.email, b.firstName, b.lastName, b.department, b.role, hash],
    );
    if (inserted.length === 0) throw new HttpError(409, 'Cette adresse e-mail est déjà utilisée.');
    res.status(201).json({ user: publicUser(inserted[0]), temporaryPassword: password });
  }),
);

const importSchema = z.object({
  rows: z
    .array(z.object({ email, firstName: name('Prénom'), lastName: name('Nom'), department }))
    .min(1, 'Aucune ligne à importer.')
    .max(200, 'Maximum 200 lignes par import.'),
});

router.post(
  '/import',
  h(async (req, res) => {
    const { rows } = importSchema.parse(req.body);
    const created: { email: string; firstName: string; lastName: string; department: string | null; temporaryPassword: string }[] = [];
    const skipped: string[] = [];
    const seen = new Set<string>();
    for (const r of rows) {
      if (seen.has(r.email)) {
        skipped.push(r.email);
        continue;
      }
      seen.add(r.email);
      const password = generatePassword();
      const hash = await bcrypt.hash(password, 10);
      const inserted = await q(
        `INSERT INTO users (email, first_name, last_name, department, role, password_hash, must_change_password)
         VALUES ($1, $2, $3, $4, 'LEARNER', $5, TRUE)
         ON CONFLICT (email) DO NOTHING RETURNING id`,
        [r.email, r.firstName, r.lastName, r.department, hash],
      );
      if (inserted.length === 0) skipped.push(r.email);
      else created.push({ ...r, temporaryPassword: password });
    }
    res.status(201).json({ created, skipped });
  }),
);

const updateSchema = z.object({
  firstName: name('Prénom').optional(),
  lastName: name('Nom').optional(),
  department: department.optional(),
  role: role.optional(),
  active: z.boolean().optional(),
  resetPassword: z.boolean().optional(),
});

router.patch(
  '/:id',
  h(async (req, res) => {
    const id = idParam(req);
    const b = updateSchema.parse(req.body);
    const [target] = await q('SELECT * FROM users WHERE id = $1', [id]);
    if (!target) throw new HttpError(404, 'Utilisateur introuvable.');

    const isAdmin = req.user!.role === 'ADMIN';
    if (!isAdmin && (target.role !== 'LEARNER' || (b.role && b.role !== 'LEARNER'))) {
      throw new HttpError(403, 'Vous ne pouvez gérer que les comptes apprenants.');
    }
    if (id === req.user!.id && ((b.role && b.role !== target.role) || b.active === false)) {
      throw new HttpError(400, 'Vous ne pouvez pas modifier votre propre rôle ni désactiver votre compte.');
    }

    const sets: string[] = [];
    const vals: unknown[] = [];
    const add = (col: string, val: unknown) => {
      vals.push(val);
      sets.push(`${col} = $${vals.length}`);
    };
    if (b.firstName !== undefined) add('first_name', b.firstName);
    if (b.lastName !== undefined) add('last_name', b.lastName);
    if (b.department !== undefined) add('department', b.department);
    if (b.role !== undefined) add('role', b.role);
    if (b.active !== undefined) add('active', b.active);

    let temporaryPassword: string | undefined;
    if (b.resetPassword) {
      temporaryPassword = generatePassword();
      add('password_hash', await bcrypt.hash(temporaryPassword, 10));
      add('must_change_password', true);
    }

    if (sets.length === 0) return res.json({ user: publicUser(target) });
    vals.push(id);
    const [updated] = await q(`UPDATE users SET ${sets.join(', ')} WHERE id = $${vals.length} RETURNING *`, vals);
    res.json({ user: publicUser(updated), temporaryPassword });
  }),
);

router.delete(
  '/:id',
  requireRole('ADMIN'),
  h(async (req, res) => {
    const id = idParam(req);
    if (id === req.user!.id) throw new HttpError(400, 'Vous ne pouvez pas supprimer votre propre compte.');
    await q('DELETE FROM users WHERE id = $1', [id]);
    res.status(204).end();
  }),
);

export default router;
