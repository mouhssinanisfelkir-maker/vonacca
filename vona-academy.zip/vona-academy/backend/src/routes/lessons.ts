import fs from 'fs';
import { Router } from 'express';
import { z } from 'zod';
import { authenticate, requireRole } from '../auth';
import { q, withTx } from '../db';
import { HttpError, h } from '../errors';
import { lessonAccess } from '../services';
import { removeVideoFile, videoPath, videoUpload } from '../upload';
import { idParam } from '../util';
import { lessonFields } from './courses';

const router = Router();
router.use(authenticate);

// ---------- Streaming vidéo (protégé, avec support des Range pour la lecture/seek) ----------

router.get(
  '/:id/video',
  h(async (req, res) => {
    const { lesson } = await lessonAccess(req.user!, idParam(req));
    if (!lesson.video_file) throw new HttpError(404, 'Aucune vidéo pour cette leçon.');
    const file = videoPath(lesson.video_file);
    const stat = await fs.promises.stat(file).catch(() => null);
    if (!stat) throw new HttpError(404, 'Fichier vidéo introuvable.');

    const size = stat.size;
    res.setHeader('Content-Type', lesson.video_mime || 'video/mp4');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'private, max-age=3600');
    res.setHeader('X-Content-Type-Options', 'nosniff');

    const range = req.headers.range;
    let start = 0;
    let end = size - 1;
    if (range) {
      const m = /^bytes=(\d*)-(\d*)$/.exec(range);
      if (!m || (m[1] === '' && m[2] === '')) {
        res.status(416).setHeader('Content-Range', `bytes */${size}`).end();
        return;
      }
      if (m[1] === '') {
        // suffixe : les N derniers octets
        start = Math.max(size - parseInt(m[2], 10), 0);
      } else {
        start = parseInt(m[1], 10);
        if (m[2] !== '') end = Math.min(parseInt(m[2], 10), size - 1);
      }
      if (start > end || start >= size) {
        res.status(416).setHeader('Content-Range', `bytes */${size}`).end();
        return;
      }
      res.status(206);
      res.setHeader('Content-Range', `bytes ${start}-${end}/${size}`);
    }
    res.setHeader('Content-Length', end - start + 1);
    const stream = fs.createReadStream(file, { start, end });
    res.on('close', () => stream.destroy());
    stream.on('error', () => res.destroy());
    stream.pipe(res);
  }),
);

// ---------- Gestion des leçons (ADMIN / RH) ----------

router.patch(
  '/:id',
  requireRole('ADMIN', 'RH'),
  videoUpload,
  h(async (req, res) => {
    try {
      const id = idParam(req);
      const b = lessonFields.partial().parse(req.body);
      const [lesson] = await q('SELECT * FROM lessons WHERE id = $1', [id]);
      if (!lesson) throw new HttpError(404, 'Leçon introuvable.');

      const sets: string[] = [];
      const vals: unknown[] = [];
      const add = (col: string, val: unknown) => {
        vals.push(val);
        sets.push(`${col} = $${vals.length}`);
      };
      if (b.title !== undefined) add('title', b.title);
      if (b.description !== undefined) add('description', b.description);
      const f = req.file;
      if (f) {
        add('video_file', f.filename);
        add('video_original_name', f.originalname);
        add('video_mime', f.mimetype);
        add('duration_seconds', b.durationSeconds ?? null);
      } else if (b.durationSeconds !== undefined) {
        add('duration_seconds', b.durationSeconds);
      }
      if (sets.length) {
        vals.push(id);
        await q(`UPDATE lessons SET ${sets.join(', ')} WHERE id = $${vals.length}`, vals);
      }
      if (f) {
        // Nouvelle vidéo : on repart de zéro pour ceux qui n'ont pas encore validé la leçon
        await q('UPDATE lesson_progress SET max_position = 0, video_completed = FALSE WHERE lesson_id = $1 AND passed = FALSE', [id]);
        await removeVideoFile(lesson.video_file);
      }
      res.json({ id });
    } catch (e) {
      await removeVideoFile(req.file?.filename);
      throw e;
    }
  }),
);

router.delete(
  '/:id',
  requireRole('ADMIN', 'RH'),
  h(async (req, res) => {
    const id = idParam(req);
    const [lesson] = await q('SELECT video_file FROM lessons WHERE id = $1', [id]);
    if (!lesson) throw new HttpError(404, 'Leçon introuvable.');
    await q('DELETE FROM lessons WHERE id = $1', [id]);
    await removeVideoFile(lesson.video_file);
    res.status(204).end();
  }),
);

const quizSchema = z.object({
  questions: z
    .array(
      z
        .object({
          text: z.string().trim().min(1, 'Chaque question doit avoir un intitulé.').max(1000),
          multiple: z.boolean(),
          options: z
            .array(z.object({ text: z.string().trim().min(1, 'Chaque réponse doit avoir un texte.').max(500), correct: z.boolean() }))
            .min(2, 'Chaque question doit avoir au moins 2 réponses.')
            .max(8, 'Maximum 8 réponses par question.'),
        })
        .refine((x) => x.options.some((o) => o.correct), { message: 'Chaque question doit avoir au moins une bonne réponse.' })
        .refine((x) => x.multiple || x.options.filter((o) => o.correct).length === 1, {
          message: 'Une question à choix unique doit avoir exactement une bonne réponse.',
        }),
    )
    .max(50, 'Maximum 50 questions par quiz.'),
});

router.put(
  '/:id/quiz',
  requireRole('ADMIN', 'RH'),
  h(async (req, res) => {
    const id = idParam(req);
    const { questions } = quizSchema.parse(req.body);
    const [lesson] = await q('SELECT id FROM lessons WHERE id = $1', [id]);
    if (!lesson) throw new HttpError(404, 'Leçon introuvable.');
    await withTx(async (c) => {
      await c.query('DELETE FROM questions WHERE lesson_id = $1', [id]);
      for (let i = 0; i < questions.length; i++) {
        const qu = questions[i];
        const { rows } = await c.query('INSERT INTO questions (lesson_id, position, text, multiple) VALUES ($1, $2, $3, $4) RETURNING id', [
          id,
          i + 1,
          qu.text,
          qu.multiple,
        ]);
        for (let j = 0; j < qu.options.length; j++) {
          await c.query('INSERT INTO options (question_id, position, text, correct) VALUES ($1, $2, $3, $4)', [
            rows[0].id,
            j + 1,
            qu.options[j].text,
            qu.options[j].correct,
          ]);
        }
      }
    });
    res.json({ ok: true, count: questions.length });
  }),
);

export default router;
