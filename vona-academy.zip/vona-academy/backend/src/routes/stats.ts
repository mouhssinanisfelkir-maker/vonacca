import { Router } from 'express';
import { authenticate, requireRole } from '../auth';
import { q } from '../db';
import { h } from '../errors';

const router = Router();
router.use(authenticate, requireRole('ADMIN', 'RH'));

router.get(
  '/',
  h(async (_req, res) => {
    const roles = await q("SELECT role, COUNT(*)::int AS n FROM users WHERE active GROUP BY role");
    const [courses] = await q('SELECT COUNT(*)::int AS total, (COUNT(*) FILTER (WHERE published))::int AS published FROM courses');
    const [assignments] = await q(
      `WITH totals AS (SELECT course_id, COUNT(*) AS n FROM lessons GROUP BY course_id),
            done AS (
              SELECT a.course_id, a.user_id, COUNT(lp.lesson_id) FILTER (WHERE lp.passed) AS p
                FROM assignments a
                JOIN lessons l ON l.course_id = a.course_id
                LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = a.user_id
               GROUP BY a.course_id, a.user_id
            )
       SELECT (SELECT COUNT(*) FROM assignments)::int AS total,
              (COUNT(*) FILTER (WHERE d.p = t.n AND t.n > 0))::int AS completed
         FROM done d JOIN totals t USING (course_id)`,
    );
    const recent = await q(
      `SELECT u.id AS user_id, u.first_name, u.last_name, c.title AS course_title, l.title AS lesson_title,
              qa.score, qa.passed, qa.created_at
         FROM quiz_attempts qa
         JOIN users u ON u.id = qa.user_id
         JOIN lessons l ON l.id = qa.lesson_id
         JOIN courses c ON c.id = l.course_id
        ORDER BY qa.created_at DESC
        LIMIT 10`,
    );
    const count = (role: string) => roles.find((r) => r.role === role)?.n ?? 0;
    res.json({
      users: { ADMIN: count('ADMIN'), RH: count('RH'), LEARNER: count('LEARNER') },
      courses: { total: courses.total, published: courses.published },
      assignments: { total: assignments?.total ?? 0, completed: assignments?.completed ?? 0 },
      recent: recent.map((r) => ({
        userId: r.user_id,
        firstName: r.first_name,
        lastName: r.last_name,
        courseTitle: r.course_title,
        lessonTitle: r.lesson_title,
        score: r.score,
        passed: r.passed,
        createdAt: r.created_at,
      })),
    });
  }),
);

export default router;
