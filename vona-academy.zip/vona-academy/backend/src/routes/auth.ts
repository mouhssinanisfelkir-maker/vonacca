import bcrypt from 'bcryptjs';
import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { authenticate, clearSession, setSession } from '../auth';
import { q } from '../db';
import { HttpError, h } from '../errors';
import { publicUser } from '../util';

const router = Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Trop de tentatives de connexion. Réessayez dans quelques minutes.' },
});

router.post(
  '/login',
  loginLimiter,
  h(async (req, res) => {
    const { email, password } = z
      .object({ email: z.string().trim().min(1, 'E-mail obligatoire.'), password: z.string().min(1, 'Mot de passe obligatoire.') })
      .parse(req.body);
    const [u] = await q('SELECT * FROM users WHERE lower(email) = lower($1)', [email]);
    const ok = u && u.active && (await bcrypt.compare(password, u.password_hash));
    if (!ok) throw new HttpError(401, 'Identifiants incorrects.');
    setSession(res, u.id);
    res.json({ user: publicUser(u) });
  }),
);

router.post('/logout', (_req, res) => {
  clearSession(res);
  res.status(204).end();
});

router.get(
  '/me',
  authenticate,
  h(async (req, res) => {
    const [u] = await q('SELECT * FROM users WHERE id = $1', [req.user!.id]);
    res.json({ user: publicUser(u) });
  }),
);

router.post(
  '/change-password',
  authenticate,
  h(async (req, res) => {
    const { currentPassword, newPassword } = z
      .object({
        currentPassword: z.string().min(1, 'Mot de passe actuel obligatoire.'),
        newPassword: z.string().min(8, 'Le nouveau mot de passe doit contenir au moins 8 caractères.').max(128),
      })
      .parse(req.body);
    const [u] = await q('SELECT * FROM users WHERE id = $1', [req.user!.id]);
    if (!(await bcrypt.compare(currentPassword, u.password_hash))) {
      throw new HttpError(400, 'Le mot de passe actuel est incorrect.');
    }
    if (currentPassword === newPassword) throw new HttpError(400, 'Le nouveau mot de passe doit être différent.');
    const hash = await bcrypt.hash(newPassword, 10);
    const [updated] = await q('UPDATE users SET password_hash = $1, must_change_password = FALSE WHERE id = $2 RETURNING *', [
      hash,
      u.id,
    ]);
    res.json({ user: publicUser(updated) });
  }),
);

export default router;
