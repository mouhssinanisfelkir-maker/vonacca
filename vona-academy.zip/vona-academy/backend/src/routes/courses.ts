import { Router } from 'express';
import { z } from 'zod';
import { authenticate, requireRole } from '../auth';
import { q, withTx } from '../db';
import { HttpError, h } from '../errors';
import { loadCourseFull, getTracking } from '../services';
import { removeVideoFile, videoUpload } from '../upload';
import { idParam } from '../util';

const router = Router();
router.use(authenticate, requireRole('ADMIN', 'RH'));

const courseFields = z.object({
  title: z.string().trim().min(1, 'Le titre est obligatoire.').max(200),
  description: z.string().max(5000).default(''),
  passScore: z.number().int().min(1, 'Le score minimum doit être entre 1 et 100.').max(100, 'Le score minimum doit être entre 1 et 100.').default(70),
});

// ---------- Liste / création ----------

router.get(
  '/',
  h(async (_req, res) => {
    const rows = await q(
      `SELECT c.id, c.title, c.description, c.pass_score, c.published, c.created_at,
              (SELECT COUNT(*) FROM lessons l WHERE l.course_id = c.id)::int AS lesson_count,
              (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.id)::int AS assigned_count,
              (SELECT COUNT(*) FROM assignments a
                WHERE a.course_id = c.id
                  AND EXISTS (SELECT 1 FROM lessons l WHERE l.course_id = c.id)
                  AND NOT EXISTS (
                    SELECT 1 FROM lessons l
                      LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = a.user_id
                     WHERE l.course_id = c.id AND COALESCE(lp.passed, FALSE) = FALSE
                  ))::int AS completed_count
         FROM courses c
        ORDER BY c.created_at DESC`,
    );
    res.json(
      rows.map((r) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        passScore: r.pass_score,
        published: r.published,
        createdAt: r.created_at,
        lessonCount: r.lesson_count,
        assignedCount: r.assigned_count,
        completedCount: r.completed_count,
      })),
    );
  }),
);

router.post(
  '/',
  h(async (req, res) => {
    const b = courseFields.parse(req.body);
    const [c] = await q(
      'INSERT INTO courses (title, description, pass_score, created_by) VALUES ($1, $2, $3, $4) RETURNING id',
      [b.title, b.description, b.passScore, req.user!.id],
    );
    res.status(201).json({ id: c.id });
  }),
);

// ---------- Détail / modification / suppression ----------

router.get(
  '/:id',
  h(async (req, res) => {
    const course = await loadCourseFull(idParam(req));
    if (!course) throw new HttpError(404, 'Formation introuvable.');
    res.json(course);
  }),
);

async function publishProblems(courseId: number): Promise<string[]> {
  const course = await loadCourseFull(courseId);
  if (!course) return ['Formation introuvable.'];
  const problems: string[] = [];
  if (course.lessons.length === 0) problems.push('La formation doit contenir au moins une leçon.');
  for (const l of course.lessons) {
    if (!l.hasVideo) problems.push(`Leçon « ${l.title} » : la vidéo est manquante.`);
    if (l.questions.length === 0) problems.push(`Leçon « ${l.title} » : le quiz doit contenir au moins une question.`);
  }
  return problems;
}

router.patch(
  '/:id',
  h(async (req, res) => {
    const id = idParam(req);
    const b = courseFields.partial().extend({ published: z.boolean().optional() }).parse(req.body);
    const [existing] = await q('SELECT id FROM courses WHERE id = $1', [id]);
    if (!existing) throw new HttpError(404, 'Formation introuvable.');

    if (b.published === true) {
      const problems = await publishProblems(id);
      if (problems.length) throw new HttpError(400, `Publication impossible. ${problems.join(' ')}`);
    }

    const sets: string[] = [];
    const vals: unknown[] = [];
    const add = (col: string, val: unknown) => {
      vals.push(val);
      sets.push(`${col} = $${vals.length}`);
    };
    if (b.title !== undefined) add('title', b.title);
    if (b.description !== undefined) add('description', b.description);
    if (b.passScore !== undefined) add('pass_score', b.passScore);
    if (b.published !== undefined) add('published', b.published);
    if (sets.length) {
      vals.push(id);
      await q(`UPDATE courses SET ${sets.join(', ')} WHERE id = $${vals.length}`, vals);
    }
    res.json(await loadCourseFull(id));
  }),
);

router.delete(
  '/:id',
  h(async (req, res) => {
    const id = idParam(req);
    const files = await q('SELECT video_file FROM lessons WHERE course_id = $1 AND video_file IS NOT NULL', [id]);
    await q('DELETE FROM courses WHERE id = $1', [id]);
    await Promise.all(files.map((f) => removeVideoFile(f.video_file)));
    res.status(204).end();
  }),
);

// ---------- Leçons ----------

export const lessonFields = z.object({
  title: z.string().trim().min(1, 'Le titre de la leçon est obligatoire.').max(200),
  description: z.string().max(5000).default(''),
  durationSeconds: z.preprocess((v) => (v === '' || v === undefined ? undefined : v), z.coerce.number().positive().optional()),
});

router.post(
  '/:id/lessons',
  videoUpload,
  h(async (req, res) => {
    try {
      const courseId = idParam(req);
      const b = lessonFields.parse(req.body);
      const [course] = await q('SELECT id FROM courses WHERE id = $1', [courseId]);
      if (!course) throw new HttpError(404, 'Formation introuvable.');
      const [{ pos }] = await q('SELECT COALESCE(MAX(position), 0) + 1 AS pos FROM lessons WHERE course_id = $1', [courseId]);
      const f = req.file;
      const [lesson] = await q(
        `INSERT INTO lessons (course_id, position, title, description, video_file, video_original_name, video_mime, duration_seconds)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`,
        [courseId, pos, b.title, b.description, f?.filename ?? null, f?.originalname ?? null, f?.mimetype ?? null, f ? (b.durationSeconds ?? null) : null],
      );
      res.status(201).json({ id: lesson.id });
    } catch (e) {
      await removeVideoFile(req.file?.filename);
      throw e;
    }
  }),
);

router.put(
  '/:id/lessons/order',
  h(async (req, res) => {
    const courseId = idParam(req);
    const { ids } = z.object({ ids: z.array(z.number().int()) }).parse(req.body);
    const current = await q('SELECT id FROM lessons WHERE course_id = $1', [courseId]);
    const same = ids.length === current.length && current.every((l) => ids.includes(l.id));
    if (!same) throw new HttpError(400, "L'ordre des leçons ne correspond pas à la formation.");
    await withTx(async (c) => {
      for (let i = 0; i < ids.length; i++) {
        await c.query('UPDATE lessons SET position = $1 WHERE id = $2', [i + 1, ids[i]]);
      }
    });
    res.json(await loadCourseFull(courseId));
  }),
);

// ---------- Affectations ----------

router.get(
  '/:id/assignments',
  h(async (req, res) => {
    const rows = await q('SELECT user_id FROM assignments WHERE course_id = $1', [idParam(req)]);
    res.json({ userIds: rows.map((r) => r.user_id as number) });
  }),
);

router.put(
  '/:id/assignments',
  h(async (req, res) => {
    const courseId = idParam(req);
    const { userIds } = z.object({ userIds: z.array(z.number().int()).max(5000) }).parse(req.body);
    const [course] = await q('SELECT id FROM courses WHERE id = $1', [courseId]);
    if (!course) throw new HttpError(404, 'Formation introuvable.');
    // Seuls des apprenants existants peuvent être affectés
    const valid = userIds.length
      ? (await q("SELECT id FROM users WHERE role = 'LEARNER' AND id = ANY($1::int[])", [userIds])).map((r) => r.id as number)
      : [];
    await withTx(async (c) => {
      await c.query('DELETE FROM assignments WHERE course_id = $1 AND NOT (user_id = ANY($2::int[]))', [courseId, valid]);
      for (const uid of valid) {
        await c.query('INSERT INTO assignments (course_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [courseId, uid]);
      }
    });
    res.json({ userIds: valid });
  }),
);

// ---------- Suivi ----------

router.get(
  '/:id/tracking',
  h(async (req, res) => {
    res.json(await getTracking(idParam(req)));
  }),
);

const STATUS_FR = { NOT_STARTED: 'Non commencée', IN_PROGRESS: 'En cours', COMPLETED: 'Terminée' } as const;
const csvCell = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;

router.get(
  '/:id/progress.csv',
  h(async (req, res) => {
    const id = idParam(req);
    const [course] = await q('SELECT title FROM courses WHERE id = $1', [id]);
    if (!course) throw new HttpError(404, 'Formation introuvable.');
    const rows = await getTracking(id);
    const header = ['Nom', 'Prénom', 'E-mail', 'Service', 'Leçons réussies', 'Total leçons', 'Score moyen (%)', 'Tentatives', 'Dernière activité', 'Statut'];
    const lines = rows.map((r) =>
      [
        r.lastName,
        r.firstName,
        r.email,
        r.department ?? '',
        r.lessonsPassed,
        r.totalLessons,
        r.avgScore ?? '',
        r.attempts,
        r.lastActivity ? new Date(r.lastActivity).toLocaleString('fr-FR', { timeZone: 'Europe/Paris' }) : '',
        STATUS_FR[r.status],
      ]
        .map(csvCell)
        .join(';'),
    );
    // BOM + séparateur ";" pour une ouverture directe dans Excel FR
    const csv = '﻿' + [header.map(csvCell).join(';'), ...lines].join('\r\n');
    const safeName = String(course.title).replace(/[^a-zA-Z0-9_-]+/g, '_').slice(0, 60) || 'formation';
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="suivi_${safeName}.csv"`);
    res.send(csv);
  }),
);

export default router;
