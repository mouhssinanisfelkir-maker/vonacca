import { Router } from 'express';
import { z } from 'zod';
import { authenticate, requireRole } from '../auth';
import { q } from '../db';
import { HttpError, h } from '../errors';
import { lessonAccess } from '../services';
import { idParam } from '../util';

const router = Router();
router.use(authenticate);

// ---------- Mes formations (apprenant) ----------

router.get(
  '/courses',
  requireRole('LEARNER'),
  h(async (req, res) => {
    const rows = await q(
      `SELECT c.id, c.title, c.description,
              (SELECT COUNT(*) FROM lessons l WHERE l.course_id = c.id)::int AS lesson_count,
              (SELECT COUNT(*) FROM lessons l
                 JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = $1 AND lp.passed
                WHERE l.course_id = c.id)::int AS passed_count,
              (SELECT l.id FROM lessons l
                 LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = $1
                WHERE l.course_id = c.id AND COALESCE(lp.passed, FALSE) = FALSE
                ORDER BY l.position LIMIT 1) AS next_lesson_id
         FROM assignments a
         JOIN courses c ON c.id = a.course_id
        WHERE a.user_id = $1 AND c.published
        ORDER BY a.assigned_at DESC`,
      [req.user!.id],
    );
    res.json(
      rows.map((r) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        lessonCount: r.lesson_count,
        passedCount: r.passed_count,
        nextLessonId: r.next_lesson_id ?? null,
      })),
    );
  }),
);

// ---------- Détail d'une formation : état de chaque leçon ----------

router.get(
  '/courses/:id',
  h(async (req, res) => {
    const courseId = idParam(req);
    const user = req.user!;
    const preview = user.role !== 'LEARNER';
    const [course] = await q('SELECT * FROM courses WHERE id = $1', [courseId]);
    if (!course || (!preview && !course.published)) throw new HttpError(404, 'Formation introuvable.');
    if (!preview) {
      const a = await q('SELECT 1 FROM assignments WHERE course_id = $1 AND user_id = $2', [courseId, user.id]);
      if (a.length === 0) throw new HttpError(403, 'Cette formation ne vous est pas affectée.');
    }

    const lessons = await q(
      `SELECT l.id, l.position, l.title, l.description, l.duration_seconds,
              (SELECT COUNT(*) FROM questions x WHERE x.lesson_id = l.id)::int AS question_count,
              COALESCE(lp.passed, FALSE) AS passed,
              COALESCE(lp.video_completed, FALSE) AS video_completed,
              COALESCE(lp.attempts, 0) AS attempts,
              COALESCE(lp.best_score, 0) AS best_score
         FROM lessons l
         LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = $2
        WHERE l.course_id = $1
        ORDER BY l.position`,
      [courseId, user.id],
    );

    let previousAllPassed = true;
    const out = lessons.map((l) => {
      let state: 'locked' | 'available' | 'done';
      if (preview) state = 'available';
      else if (l.passed) state = 'done';
      else state = previousAllPassed ? 'available' : 'locked';
      previousAllPassed = previousAllPassed && l.passed;
      return {
        id: l.id,
        position: l.position,
        title: l.title,
        description: l.description,
        durationSeconds: l.duration_seconds ?? null,
        questionCount: l.question_count,
        state,
        videoCompleted: l.video_completed,
        attempts: l.attempts,
        bestScore: l.attempts > 0 ? l.best_score : null,
      };
    });

    res.json({
      id: course.id,
      title: course.title,
      description: course.description,
      passScore: course.pass_score,
      published: course.published,
      preview,
      lessons: out,
    });
  }),
);

// ---------- Détail d'une leçon (vidéo + quiz une fois la vidéo terminée) ----------

router.get(
  '/lessons/:id',
  h(async (req, res) => {
    const user = req.user!;
    const lessonId = idParam(req);
    const { lesson, preview } = await lessonAccess(user, lessonId);
    const [lp] = await q('SELECT * FROM lesson_progress WHERE user_id = $1 AND lesson_id = $2', [user.id, lessonId]);
    const videoCompleted = preview || !!lp?.video_completed;

    const questions = await q('SELECT * FROM questions WHERE lesson_id = $1 ORDER BY position', [lessonId]);
    let quiz: { id: number; text: string; multiple: boolean; options: { id: number; text: string }[] }[] | null = null;
    if (videoCompleted && questions.length) {
      // Les bonnes réponses ne sont jamais envoyées à l'apprenant
      const options = await q(
        'SELECT id, question_id, text FROM options WHERE question_id = ANY($1::int[]) ORDER BY position',
        [questions.map((x) => x.id)],
      );
      quiz = questions.map((x) => ({
        id: x.id,
        text: x.text,
        multiple: x.multiple,
        options: options.filter((o) => o.question_id === x.id).map((o) => ({ id: o.id, text: o.text })),
      }));
    }

    const [next] = await q('SELECT id FROM lessons WHERE course_id = $1 AND position > $2 ORDER BY position LIMIT 1', [
      lesson.course_id,
      lesson.position,
    ]);

    res.json({
      id: lesson.id,
      courseId: lesson.course_id,
      courseTitle: lesson.course_title,
      title: lesson.title,
      description: lesson.description,
      passScore: lesson.pass_score,
      preview,
      videoUrl: lesson.video_file ? `/api/lessons/${lesson.id}/video` : null,
      durationSeconds: lesson.duration_seconds ?? null,
      maxPosition: lp?.max_position ?? 0,
      videoCompleted,
      passed: !!lp?.passed,
      bestScore: lp && lp.attempts > 0 ? lp.best_score : null,
      hasQuiz: questions.length > 0,
      quiz,
      nextLessonId: next?.id ?? null,
    });
  }),
);

// ---------- Progression de lecture (battement de cœur envoyé par le lecteur) ----------

const progressSchema = z.object({
  position: z.number().min(0),
  duration: z.number().min(0).default(0),
  ended: z.boolean().optional(),
});

router.post(
  '/lessons/:id/progress',
  h(async (req, res) => {
    const user = req.user!;
    const lessonId = idParam(req);
    const body = progressSchema.parse(req.body);
    const { lesson, preview } = await lessonAccess(user, lessonId);
    if (preview) return res.json({ maxPosition: body.position, videoCompleted: true, passed: false, preview: true });

    const [prev] = await q('SELECT * FROM lesson_progress WHERE user_id = $1 AND lesson_id = $2', [user.id, lessonId]);
    const prevMax: number = prev?.max_position ?? 0;
    const alreadyCompleted: boolean = prev?.video_completed ?? false;

    // Anti-saut : la progression ne peut pas avancer plus vite que la lecture réelle (marge x2,5).
    // L'écart temporel est plafonné à 30 s pour qu'une longue absence n'autorise pas un saut.
    const elapsed = prev ? Math.min((Date.now() - new Date(prev.updated_at).getTime()) / 1000, 30) : 0;
    const allowed = prevMax + elapsed * 2.5 + 10;
    const maxPosition = Math.min(Math.max(prevMax, body.position), allowed);

    const duration: number = lesson.duration_seconds ?? body.duration;
    const reachedEnd = duration > 0 && maxPosition >= duration * 0.95;
    const videoCompleted = alreadyCompleted || reachedEnd;

    const [{ n }] = await q('SELECT COUNT(*)::int AS n FROM questions WHERE lesson_id = $1', [lessonId]);
    // Une leçon sans quiz est validée dès que la vidéo est terminée
    const passed = !!prev?.passed || (videoCompleted && n === 0);

    await q(
      `INSERT INTO lesson_progress (user_id, lesson_id, max_position, video_completed, passed, passed_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, CASE WHEN $5 THEN now() END, now())
       ON CONFLICT (user_id, lesson_id) DO UPDATE SET
         max_position = EXCLUDED.max_position,
         video_completed = EXCLUDED.video_completed,
         passed = EXCLUDED.passed,
         passed_at = COALESCE(lesson_progress.passed_at, EXCLUDED.passed_at),
         updated_at = now()`,
      [user.id, lessonId, maxPosition, videoCompleted, passed],
    );
    res.json({ maxPosition, videoCompleted, passed });
  }),
);

// ---------- Soumission du quiz ----------

const answersSchema = z.object({ answers: z.record(z.string(), z.array(z.number().int()).max(20)) });

router.post(
  '/lessons/:id/quiz',
  h(async (req, res) => {
    const user = req.user!;
    const lessonId = idParam(req);
    const { answers } = answersSchema.parse(req.body);
    const { lesson, preview } = await lessonAccess(user, lessonId);

    const [lp] = await q('SELECT * FROM lesson_progress WHERE user_id = $1 AND lesson_id = $2', [user.id, lessonId]);
    if (!preview && !lp?.video_completed) {
      throw new HttpError(403, "Vous devez d'abord regarder la vidéo en entier avant de répondre au quiz.");
    }

    const questions = await q('SELECT id FROM questions WHERE lesson_id = $1 ORDER BY position', [lessonId]);
    if (questions.length === 0) throw new HttpError(400, "Cette leçon n'a pas de quiz.");
    const options = await q(
      'SELECT id, question_id, correct FROM options WHERE question_id = ANY($1::int[])',
      [questions.map((x) => x.id)],
    );

    const results = questions.map((qu) => {
      const correctIds = options.filter((o) => o.question_id === qu.id && o.correct).map((o) => o.id as number);
      const picked = [...new Set(answers[String(qu.id)] ?? [])];
      const correct = picked.length === correctIds.length && correctIds.every((id) => picked.includes(id));
      return { questionId: qu.id as number, correct };
    });
    const score = Math.round((100 * results.filter((r) => r.correct).length) / results.length);
    const passed = score >= lesson.pass_score;

    if (!preview) {
      await q('INSERT INTO quiz_attempts (user_id, lesson_id, score, passed) VALUES ($1, $2, $3, $4)', [user.id, lessonId, score, passed]);
      await q(
        `UPDATE lesson_progress SET
           attempts = attempts + 1,
           best_score = GREATEST(best_score, $3),
           passed = passed OR $4,
           passed_at = CASE WHEN passed THEN passed_at WHEN $4 THEN now() ELSE passed_at END,
           updated_at = now()
         WHERE user_id = $1 AND lesson_id = $2`,
        [user.id, lessonId, score, passed],
      );
    }

    const [next] = await q('SELECT id FROM lessons WHERE course_id = $1 AND position > $2 ORDER BY position LIMIT 1', [
      lesson.course_id,
      lesson.position,
    ]);
    res.json({
      score,
      passed,
      passScore: lesson.pass_score,
      results,
      nextLessonId: passed ? (next?.id ?? null) : null,
      courseCompleted: passed && !next,
      recorded: !preview,
    });
  }),
);

export default router;
