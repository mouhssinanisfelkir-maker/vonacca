import { randomInt } from 'crypto';
import { Request } from 'express';
import { HttpError } from './errors';

export function idParam(req: Request, name = 'id'): number {
  const n = Number(req.params[name]);
  if (!Number.isInteger(n) || n <= 0) throw new HttpError(400, 'Identifiant invalide.');
  return n;
}

export function publicUser(u: any) {
  return {
    id: u.id as number,
    email: u.email as string,
    firstName: u.first_name as string,
    lastName: u.last_name as string,
    department: (u.department ?? null) as string | null,
    role: u.role as 'ADMIN' | 'RH' | 'LEARNER',
    active: u.active as boolean,
    mustChangePassword: u.must_change_password as boolean,
  };
}

// Alphabet sans caractères ambigus (0/O, 1/l/I)
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
export function generatePassword(length = 10): string {
  let s = '';
  for (let i = 0; i < length; i++) s += ALPHABET[randomInt(ALPHABET.length)];
  return s;
}
