import { randomUUID } from 'crypto';
import fs from 'fs';
import multer from 'multer';
import path from 'path';
import { config } from './config';
import { HttpError } from './errors';

fs.mkdirSync(config.videoDir, { recursive: true });

const ALLOWED: Record<string, string> = {
  'video/mp4': '.mp4',
  'video/webm': '.webm',
};

export const videoUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, config.videoDir),
    filename: (_req, file, cb) => cb(null, randomUUID() + (ALLOWED[file.mimetype] ?? '.bin')),
  }),
  fileFilter: (_req, file, cb) => {
    if (ALLOWED[file.mimetype]) cb(null, true);
    else cb(new HttpError(400, 'Format vidéo non supporté : utilisez MP4 (H.264) ou WebM.'));
  },
  limits: { fileSize: config.maxVideoMb * 1024 * 1024, files: 1 },
}).single('video');

export function videoPath(filename: string): string {
  return path.join(config.videoDir, path.basename(filename));
}

export async function removeVideoFile(filename?: string | null) {
  if (!filename) return;
  await fs.promises.unlink(videoPath(filename)).catch(() => undefined);
}
