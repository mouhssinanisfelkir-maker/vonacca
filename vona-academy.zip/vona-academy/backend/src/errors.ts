import { NextFunction, Request, RequestHandler, Response } from 'express';
import multer from 'multer';
import { z, ZodError } from 'zod';

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/** Express 4 ne capture pas les erreurs des handlers async : on les transmet à next(). */
export const h =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => {
    fn(req, res, next).catch(next);
  };

// Messages de validation en français
z.setErrorMap((issue, ctx) => {
  const field = issue.path.length ? `« ${issue.path.join('.')} » : ` : '';
  switch (issue.code) {
    case z.ZodIssueCode.invalid_type:
      return { message: `${field}${issue.received === 'undefined' ? 'champ obligatoire.' : 'type de valeur invalide.'}` };
    case z.ZodIssueCode.too_small:
      return { message: `${field}valeur trop courte ou trop petite.` };
    case z.ZodIssueCode.too_big:
      return { message: `${field}valeur trop longue ou trop grande.` };
    case z.ZodIssueCode.invalid_string:
      return { message: `${field}format invalide.` };
    case z.ZodIssueCode.invalid_enum_value:
      return { message: `${field}valeur non autorisée.` };
    default:
      return { message: `${field}${ctx.defaultError}` };
  }
});

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err instanceof ZodError) {
    const msgs = [...new Set(err.issues.map((i) => i.message))];
    return res.status(400).json({ error: msgs.join(' ') });
  }
  if (err instanceof multer.MulterError) {
    const msg = err.code === 'LIMIT_FILE_SIZE' ? 'Fichier trop volumineux.' : "Erreur lors de l'envoi du fichier.";
    return res.status(400).json({ error: msg });
  }
  if ((err as { type?: string })?.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Requête invalide.' });
  }
  console.error(err);
  res.status(500).json({ error: 'Erreur interne du serveur.' });
}
