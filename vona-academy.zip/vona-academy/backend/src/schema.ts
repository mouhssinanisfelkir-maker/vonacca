import bcrypt from 'bcryptjs';
import { config } from './config';
import { pool, q } from './db';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  department TEXT,
  role TEXT NOT NULL CHECK (role IN ('ADMIN','RH','LEARNER')),
  password_hash TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS courses (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  pass_score INT NOT NULL DEFAULT 70 CHECK (pass_score BETWEEN 1 AND 100),
  published BOOLEAN NOT NULL DEFAULT FALSE,
  created_by INT REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS lessons (
  id SERIAL PRIMARY KEY,
  course_id INT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  position INT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  video_file TEXT,
  video_original_name TEXT,
  video_mime TEXT,
  duration_seconds DOUBLE PRECISION,
  UNIQUE (course_id, position) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE IF NOT EXISTS questions (
  id SERIAL PRIMARY KEY,
  lesson_id INT NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  position INT NOT NULL,
  text TEXT NOT NULL,
  multiple BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS options (
  id SERIAL PRIMARY KEY,
  question_id INT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  position INT NOT NULL,
  text TEXT NOT NULL,
  correct BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS assignments (
  course_id INT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (course_id, user_id)
);

CREATE TABLE IF NOT EXISTS lesson_progress (
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id INT NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  max_position DOUBLE PRECISION NOT NULL DEFAULT 0,
  video_completed BOOLEAN NOT NULL DEFAULT FALSE,
  passed BOOLEAN NOT NULL DEFAULT FALSE,
  best_score INT NOT NULL DEFAULT 0,
  attempts INT NOT NULL DEFAULT 0,
  passed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, lesson_id)
);

CREATE TABLE IF NOT EXISTS quiz_attempts (
  id SERIAL PRIMARY KEY,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id INT NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  score INT NOT NULL,
  passed BOOLEAN NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lessons_course ON lessons(course_id, position);
CREATE INDEX IF NOT EXISTS idx_progress_lesson ON lesson_progress(lesson_id);
CREATE INDEX IF NOT EXISTS idx_assignments_user ON assignments(user_id);
CREATE INDEX IF NOT EXISTS idx_attempts_created ON quiz_attempts(created_at DESC);
`;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function seed() {
  const admins = await q("SELECT id FROM users WHERE role = 'ADMIN' LIMIT 1");
  if (admins.length === 0) {
    if (config.adminPassword.length < 8) {
      throw new Error('ADMIN_PASSWORD (8 caractères minimum) est obligatoire pour créer le premier compte administrateur.');
    }
    const hash = await bcrypt.hash(config.adminPassword, 10);
    await q(
      `INSERT INTO users (email, first_name, last_name, role, password_hash, must_change_password)
       VALUES ($1, 'Administrateur', 'Vona', 'ADMIN', $2, TRUE)`,
      [config.adminEmail, hash],
    );
    console.log(`Compte administrateur créé : ${config.adminEmail}`);
  }

  if (config.seedDemo) {
    const hash = await bcrypt.hash('Vona2026!', 10);
    const demo: [string, string, string, string, string][] = [
      ['rh@vona.local', 'Camille', 'Martin', 'Ressources humaines', 'RH'],
      ['lucas.bernard@vona.local', 'Lucas', 'Bernard', 'Technique', 'LEARNER'],
      ['sarah.dubois@vona.local', 'Sarah', 'Dubois', 'Commercial', 'LEARNER'],
      ['karim.haddad@vona.local', 'Karim', 'Haddad', 'Support', 'LEARNER'],
    ];
    for (const [email, first, last, dept, role] of demo) {
      await q(
        `INSERT INTO users (email, first_name, last_name, department, role, password_hash)
         VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT (email) DO NOTHING`,
        [email, first, last, dept, role, hash],
      );
    }
    console.log('Comptes de démonstration créés (mot de passe : Vona2026!).');
  }
}

export async function initDatabase() {
  for (let attempt = 1; ; attempt++) {
    try {
      await pool.query('SELECT 1');
      break;
    } catch (e) {
      if (attempt >= 30) throw e;
      console.log(`En attente de la base de données (${attempt}/30)...`);
      await sleep(2000);
    }
  }
  await pool.query(SCHEMA);
  await seed();
}
