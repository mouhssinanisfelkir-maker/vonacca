import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { config } from './config';
import { q } from './db';
import { HttpError, h } from './errors';

export type Role = 'ADMIN' | 'RH' | 'LEARNER';

export interface AuthUser {
  id: number;
  email: string;
  role: Role;
  firstName: string;
  lastName: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

export const COOKIE_NAME = 'vona_session';
const SESSION_MS = 12 * 60 * 60 * 1000;

export function setSession(res: Response, userId: number) {
  const token = jwt.sign({ sub: String(userId) }, config.jwtSecret, { expiresIn: '12h' });
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.cookieSecure,
    maxAge: SESSION_MS,
    path: '/',
  });
}

export function clearSession(res: Response) {
  res.clearCookie(COOKIE_NAME, { path: '/' });
}

/** Vérifie le cookie de session et recharge l'utilisateur (un compte désactivé perd l'accès immédiatement). */
export const authenticate = h(async (req, _res, next) => {
  const token = req.cookies?.[COOKIE_NAME];
  if (!token) throw new HttpError(401, 'Non authentifié.');
  let id: number;
  try {
    const payload = jwt.verify(token, config.jwtSecret) as jwt.JwtPayload;
    id = Number(payload.sub);
  } catch {
    throw new HttpError(401, 'Session expirée.');
  }
  const [u] = await q('SELECT id, email, role, first_name, last_name, active FROM users WHERE id = $1', [id]);
  if (!u || !u.active) throw new HttpError(401, 'Compte introuvable ou désactivé.');
  req.user = { id: u.id, email: u.email, role: u.role, firstName: u.first_name, lastName: u.last_name };
  next();
});

export const requireRole =
  (...roles: Role[]) =>
  (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) return next(new HttpError(403, 'Accès refusé.'));
    next();
  };
