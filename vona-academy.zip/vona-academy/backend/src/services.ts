import { AuthUser } from './auth';
import { q } from './db';
import { HttpError } from './errors';

/** Formation complète (vue éditeur RH : les bonnes réponses sont incluses). */
export async function loadCourseFull(courseId: number) {
  const [course] = await q('SELECT * FROM courses WHERE id = $1', [courseId]);
  if (!course) return null;
  const lessons = await q('SELECT * FROM lessons WHERE course_id = $1 ORDER BY position', [courseId]);
  const lessonIds = lessons.map((l) => l.id);
  const questions = lessonIds.length
    ? await q('SELECT * FROM questions WHERE lesson_id = ANY($1::int[]) ORDER BY position', [lessonIds])
    : [];
  const questionIds = questions.map((x) => x.id);
  const options = questionIds.length
    ? await q('SELECT * FROM options WHERE question_id = ANY($1::int[]) ORDER BY position', [questionIds])
    : [];

  return {
    id: course.id as number,
    title: course.title as string,
    description: course.description as string,
    passScore: course.pass_score as number,
    published: course.published as boolean,
    lessons: lessons.map((l) => ({
      id: l.id as number,
      position: l.position as number,
      title: l.title as string,
      description: l.description as string,
      hasVideo: !!l.video_file,
      videoName: (l.video_original_name ?? null) as string | null,
      durationSeconds: (l.duration_seconds ?? null) as number | null,
      questions: questions
        .filter((x) => x.lesson_id === l.id)
        .map((x) => ({
          id: x.id as number,
          text: x.text as string,
          multiple: x.multiple as boolean,
          options: options
            .filter((o) => o.question_id === x.id)
            .map((o) => ({ id: o.id as number, text: o.text as string, correct: o.correct as boolean })),
        })),
    })),
  };
}

export type TrackingStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED';

/** Suivi des apprenants affectés à une formation. */
export async function getTracking(courseId: number) {
  const rows = await q(
    `SELECT u.id, u.first_name, u.last_name, u.email, u.department, a.assigned_at,
            COUNT(DISTINCT l.id)::int AS total_lessons,
            (COUNT(DISTINCT l.id) FILTER (WHERE lp.passed))::int AS lessons_passed,
            ROUND(AVG(CASE WHEN lp.attempts > 0 THEN lp.best_score END))::int AS avg_score,
            MAX(lp.updated_at) AS last_activity,
            COALESCE(SUM(lp.attempts), 0)::int AS attempts
       FROM assignments a
       JOIN users u ON u.id = a.user_id
       LEFT JOIN lessons l ON l.course_id = a.course_id
       LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = u.id
      WHERE a.course_id = $1
      GROUP BY u.id, a.assigned_at
      ORDER BY u.last_name, u.first_name`,
    [courseId],
  );
  return rows.map((r) => {
    const status: TrackingStatus =
      r.total_lessons > 0 && r.lessons_passed === r.total_lessons
        ? 'COMPLETED'
        : r.last_activity
          ? 'IN_PROGRESS'
          : 'NOT_STARTED';
    return {
      userId: r.id as number,
      firstName: r.first_name as string,
      lastName: r.last_name as string,
      email: r.email as string,
      department: (r.department ?? null) as string | null,
      assignedAt: r.assigned_at as string,
      lessonsPassed: r.lessons_passed as number,
      totalLessons: r.total_lessons as number,
      avgScore: (r.avg_score ?? null) as number | null,
      attempts: r.attempts as number,
      lastActivity: (r.last_activity ?? null) as string | null,
      status,
    };
  });
}

/**
 * Contrôle d'accès à une leçon.
 * - ADMIN / RH : accès libre (mode aperçu, rien n'est enregistré).
 * - Apprenant : formation publiée + affectée + toutes les leçons précédentes réussies.
 */
export async function lessonAccess(user: AuthUser, lessonId: number) {
  const [lesson] = await q(
    `SELECT l.*, c.published, c.pass_score, c.title AS course_title
       FROM lessons l JOIN courses c ON c.id = l.course_id
      WHERE l.id = $1`,
    [lessonId],
  );
  if (!lesson) throw new HttpError(404, 'Leçon introuvable.');
  if (user.role !== 'LEARNER') return { lesson, preview: true };

  if (!lesson.published) throw new HttpError(404, 'Leçon introuvable.');
  const assigned = await q('SELECT 1 FROM assignments WHERE course_id = $1 AND user_id = $2', [lesson.course_id, user.id]);
  if (assigned.length === 0) throw new HttpError(403, "Cette formation ne vous est pas affectée.");

  const blocking = await q(
    `SELECT 1
       FROM lessons l2
       LEFT JOIN lesson_progress lp ON lp.lesson_id = l2.id AND lp.user_id = $3
      WHERE l2.course_id = $1 AND l2.position < $2 AND COALESCE(lp.passed, FALSE) = FALSE
      LIMIT 1`,
    [lesson.course_id, lesson.position, user.id],
  );
  if (blocking.length > 0) {
    throw new HttpError(403, 'Vous devez d\'abord réussir le quiz de la leçon précédente.');
  }
  return { lesson, preview: false };
}
