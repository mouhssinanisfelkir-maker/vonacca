function required(name: string, value: string | undefined, min = 1): string {
  if (!value || value.length < min) {
    throw new Error(`Variable d'environnement ${name} manquante ou trop courte (minimum ${min} caractères).`);
  }
  return value;
}

export const config = {
  port: Number(process.env.PORT ?? 4000),
  databaseUrl: required('DATABASE_URL', process.env.DATABASE_URL),
  jwtSecret: required('JWT_SECRET', process.env.JWT_SECRET, 32),
  // À passer à "true" dès que la plateforme est servie en HTTPS (Azure, reverse proxy TLS...)
  cookieSecure: process.env.COOKIE_SECURE === 'true',
  videoDir: process.env.VIDEO_DIR ?? '/data/videos',
  maxVideoMb: Number(process.env.MAX_VIDEO_MB ?? 2048),
  adminEmail: (process.env.ADMIN_EMAIL ?? 'admin@vona.local').toLowerCase(),
  adminPassword: process.env.ADMIN_PASSWORD ?? '',
  seedDemo: process.env.SEED_DEMO === 'true',
};
