export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}

function sessionExpired(status: number, url: string) {
  if (status === 401 && !url.startsWith('/auth/login')) window.dispatchEvent(new Event('session-expired'));
}

async function request<T>(method: string, url: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch('/api' + url, {
      method,
      credentials: 'same-origin',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError('Impossible de joindre le serveur. Vérifiez votre connexion.', 0);
  }
  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    sessionExpired(res.status, url);
    throw new ApiError(data?.error ?? `Erreur ${res.status}`, res.status);
  }
  return data as T;
}

/** Envoi multipart avec suivi de progression (vidéos volumineuses). */
function upload<T>(method: 'POST' | 'PATCH', url: string, form: FormData, onProgress?: (pct: number) => void): Promise<T> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(method, '/api' + url);
    xhr.responseType = 'json';
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress?.(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve(xhr.response as T);
      else {
        sessionExpired(xhr.status, url);
        reject(new ApiError(xhr.response?.error ?? "Erreur lors de l'envoi.", xhr.status));
      }
    };
    xhr.onerror = () => reject(new ApiError("Connexion perdue pendant l'envoi.", 0));
    xhr.send(form);
  });
}

export const api = {
  get: <T>(url: string) => request<T>('GET', url),
  post: <T>(url: string, body?: unknown) => request<T>('POST', url, body ?? {}),
  put: <T>(url: string, body: unknown) => request<T>('PUT', url, body),
  patch: <T>(url: string, body: unknown) => request<T>('PATCH', url, body),
  del: <T = void>(url: string) => request<T>('DELETE', url),
  upload,
};
