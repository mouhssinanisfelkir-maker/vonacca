import { Navigate, Outlet, Route, Routes } from 'react-router-dom';
import { useAuth } from './auth';
import Layout from './components/Layout';
import { Spinner } from './components/ui';
import { Role } from './types';
import ChangePassword from './pages/ChangePassword';
import Login from './pages/Login';
import CourseView from './pages/learner/CourseView';
import LessonPlayer from './pages/learner/LessonPlayer';
import MyCourses from './pages/learner/MyCourses';
import CourseEditor from './pages/staff/CourseEditor';
import Courses from './pages/staff/Courses';
import Dashboard from './pages/staff/Dashboard';
import Users from './pages/staff/Users';

function homeFor(role: Role) {
  return role === 'ADMIN' ? '/admin' : role === 'RH' ? '/rh' : '/';
}

/** Exige une session ; force le changement du mot de passe temporaire. */
function RequireAuth() {
  const { user, loading } = useAuth();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (user.mustChangePassword) return <ChangePassword forced />;
  return <Outlet />;
}

function RequireRole({ roles }: { roles: Role[] }) {
  const { user } = useAuth();
  if (!user || !roles.includes(user.role)) return <Navigate to="/" replace />;
  return <Outlet />;
}

function Home() {
  const { user } = useAuth();
  if (!user) return null;
  if (user.role !== 'LEARNER') return <Navigate to={homeFor(user.role)} replace />;
  return <MyCourses />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<RequireAuth />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/password" element={<ChangePassword />} />

          {/* Espace apprenant (accessible aussi aux RH/Admin en mode aperçu) */}
          <Route path="/courses/:courseId" element={<CourseView />} />
          <Route path="/courses/:courseId/lessons/:lessonId" element={<LessonPlayer />} />

          {/* Espace Admin */}
          <Route element={<RequireRole roles={['ADMIN']} />}>
            <Route path="/admin" element={<Dashboard space="admin" />} />
            <Route path="/admin/users" element={<Users scope="admin" />} />
          </Route>

          {/* Espace RH (l'admin y a aussi accès) */}
          <Route element={<RequireRole roles={['ADMIN', 'RH']} />}>
            <Route path="/rh" element={<Dashboard space="rh" />} />
            <Route path="/rh/courses" element={<Courses />} />
            <Route path="/rh/courses/:courseId" element={<CourseEditor />} />
            <Route path="/rh/learners" element={<Users scope="rh" />} />
          </Route>
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
