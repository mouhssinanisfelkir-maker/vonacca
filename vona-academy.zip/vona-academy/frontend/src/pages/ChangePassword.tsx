import { FormEvent, useState } from 'react';
import { useAuth } from '../auth';
import { api } from '../api';
import { Alert, Field, Logo } from '../components/ui';
import { User } from '../types';

export default function ChangePassword({ forced }: { forced?: boolean }) {
  const { setUser, logout } = useAuth();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setDone(false);
    if (next !== confirm) return setError('Les deux nouveaux mots de passe ne correspondent pas.');
    setBusy(true);
    try {
      const r = await api.post<{ user: User }>('/auth/change-password', { currentPassword: current, newPassword: next });
      setCurrent('');
      setNext('');
      setConfirm('');
      setDone(true);
      setUser(r.user);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const form = (
    <form className={forced ? 'login-card' : 'card'} style={forced ? undefined : { maxWidth: 460 }} onSubmit={submit}>
      {forced ? (
        <>
          <Logo />
          <h1>Choisissez votre mot de passe personnel</h1>
          <Alert kind="info">Votre mot de passe actuel est temporaire. Pour continuer, définissez-en un nouveau (8 caractères minimum).</Alert>
        </>
      ) : (
        <h2>Changer mon mot de passe</h2>
      )}
      {error && <Alert>{error}</Alert>}
      {done && !forced && <Alert kind="ok">Mot de passe modifié.</Alert>}
      <Field label="Mot de passe actuel">
        <input className="input" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} required />
      </Field>
      <Field label="Nouveau mot de passe" hint="8 caractères minimum">
        <input className="input" type="password" autoComplete="new-password" minLength={8} value={next} onChange={(e) => setNext(e.target.value)} required />
      </Field>
      <Field label="Confirmer le nouveau mot de passe">
        <input className="input" type="password" autoComplete="new-password" minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
      </Field>
      <div className="row">
        <button className="btn btn-primary" disabled={busy}>
          {busy ? 'Enregistrement…' : 'Enregistrer'}
        </button>
        {forced && (
          <button type="button" className="btn" onClick={() => logout()}>
            Se déconnecter
          </button>
        )}
      </div>
    </form>
  );

  return forced ? <div className="login-page">{form}</div> : form;
}
