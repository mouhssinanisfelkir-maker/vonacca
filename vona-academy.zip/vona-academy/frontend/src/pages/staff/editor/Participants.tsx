import { useEffect, useMemo, useState } from 'react';
import { api } from '../../../api';
import { Alert, Empty, Spinner } from '../../../components/ui';
import { useLoad } from '../../../hooks';
import { User } from '../../../types';

export default function Participants({ courseId, published }: { courseId: number; published: boolean }) {
  const users = useLoad(() => api.get<User[]>('/users'), []);
  const assigned = useLoad(() => api.get<{ userIds: number[] }>(`/courses/${courseId}/assignments`), [courseId]);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [initial, setInitial] = useState<Set<number>>(new Set());
  const [search, setSearch] = useState('');
  const [dept, setDept] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (assigned.data) {
      const s = new Set(assigned.data.userIds);
      setSelected(s);
      setInitial(s);
    }
  }, [assigned.data]);

  const learners = useMemo(() => (users.data ?? []).filter((u) => u.role === 'LEARNER' && u.active), [users.data]);
  const departments = useMemo(() => [...new Set(learners.map((u) => u.department).filter((d): d is string => !!d))].sort(), [learners]);
  const visible = learners.filter((u) => {
    if (dept && u.department !== dept) return false;
    return `${u.firstName} ${u.lastName} ${u.email}`.toLowerCase().includes(search.toLowerCase());
  });
  const dirty = selected.size !== initial.size || [...selected].some((id) => !initial.has(id));

  const toggle = (id: number) =>
    setSelected((s) => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  const selectVisible = (on: boolean) =>
    setSelected((s) => {
      const n = new Set(s);
      visible.forEach((u) => (on ? n.add(u.id) : n.delete(u.id)));
      return n;
    });

  async function save() {
    setBusy(true);
    setMsg(null);
    try {
      const r = await api.put<{ userIds: number[] }>(`/courses/${courseId}/assignments`, { userIds: [...selected] });
      const s = new Set(r.userIds);
      setSelected(s);
      setInitial(s);
      setMsg({ kind: 'ok', text: `Affectation enregistrée : ${s.size} apprenant${s.size > 1 ? 's' : ''}.` });
    } catch (e) {
      setMsg({ kind: 'error', text: (e as Error).message });
    } finally {
      setBusy(false);
    }
  }

  if ((users.loading && !users.data) || (assigned.loading && !assigned.data)) return <Spinner />;
  if (users.error || assigned.error) return <Alert>{users.error ?? assigned.error}</Alert>;

  return (
    <>
      {!published && <Alert kind="warn">La formation est en brouillon : les apprenants choisis ne la verront qu’une fois publiée.</Alert>}
      {msg && <Alert kind={msg.kind}>{msg.text}</Alert>}
      {learners.length === 0 ? (
        <Empty>Aucun apprenant actif. Créez d’abord des comptes dans l’onglet « Apprenants ».</Empty>
      ) : (
        <>
          <div className="toolbar">
            <input className="input" placeholder="Rechercher un apprenant…" value={search} onChange={(e) => setSearch(e.target.value)} />
            <select className="input" value={dept} onChange={(e) => setDept(e.target.value)}>
              <option value="">Tous les services</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
            <button className="btn btn-sm" onClick={() => selectVisible(true)}>
              Tout sélectionner ({visible.length})
            </button>
            <button className="btn btn-sm" onClick={() => selectVisible(false)}>
              Tout désélectionner
            </button>
            <span className="spacer" />
            <strong>{selected.size} sélectionné{selected.size > 1 ? 's' : ''}</strong>
            <button className="btn btn-primary" onClick={save} disabled={busy || !dirty}>
              {busy ? 'Enregistrement…' : 'Enregistrer'}
            </button>
          </div>
          <div className="check-list">
            {visible.length === 0 && <div className="check-row muted">Aucun résultat.</div>}
            {visible.map((u) => (
              <label className="check-row" key={u.id}>
                <input type="checkbox" checked={selected.has(u.id)} onChange={() => toggle(u.id)} />
                <span style={{ flex: 1 }}>
                  <strong>
                    {u.firstName} {u.lastName}
                  </strong>{' '}
                  <span className="muted small">{u.email}</span>
                </span>
                <span className="small muted">{u.department ?? ''}</span>
              </label>
            ))}
          </div>
          <p className="small muted" style={{ marginTop: 10 }}>
            Un apprenant désélectionné n’a plus accès à la formation ; sa progression est conservée s’il est réaffecté plus tard.
          </p>
        </>
      )}
    </>
  );
}
