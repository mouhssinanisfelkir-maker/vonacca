import { FormEvent, useState } from 'react';
import { api } from '../../../api';
import { Alert, Field, Modal, ProgressBar } from '../../../components/ui';
import { formatDuration } from '../../../hooks';
import { EditorLesson } from '../../../types';

function readDuration(file: File): Promise<number | null> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement('video');
    v.preload = 'metadata';
    v.onloadedmetadata = () => {
      URL.revokeObjectURL(url);
      resolve(Number.isFinite(v.duration) ? v.duration : null);
    };
    v.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(null);
    };
    v.src = url;
  });
}

const formatSize = (b: number) => (b > 1e9 ? `${(b / 1e9).toFixed(2)} Go` : `${Math.round(b / 1e6)} Mo`);

export default function LessonModal({
  courseId,
  lesson,
  onClose,
  onSaved,
}: {
  courseId: number;
  lesson: EditorLesson | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState(lesson?.title ?? '');
  const [description, setDescription] = useState(lesson?.description ?? '');
  const [file, setFile] = useState<File | null>(null);
  const [duration, setDuration] = useState<number | null>(null);
  const [unreadable, setUnreadable] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onFile(f: File | null) {
    setFile(f);
    setDuration(null);
    setUnreadable(false);
    if (!f) return;
    const d = await readDuration(f);
    setDuration(d);
    setUnreadable(d === null);
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setProgress(file ? 0 : null);
    const form = new FormData();
    form.set('title', title);
    form.set('description', description);
    if (file) {
      if (duration) form.set('durationSeconds', String(duration));
      form.set('video', file); // le fichier doit venir en dernier pour que les champs texte soient lus avant
    }
    try {
      if (lesson) await api.upload('PATCH', `/lessons/${lesson.id}`, form, setProgress);
      else await api.upload('POST', `/courses/${courseId}/lessons`, form, setProgress);
      onSaved();
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
      setProgress(null);
    }
  }

  return (
    <Modal title={lesson ? 'Modifier la leçon' : 'Ajouter une leçon'} onClose={busy ? () => undefined : onClose}>
      <form onSubmit={submit}>
        {error && <Alert>{error}</Alert>}
        <Field label="Titre de la leçon">
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} required autoFocus maxLength={200} disabled={busy} />
        </Field>
        <Field label="Description (facultatif)">
          <textarea className="input" value={description} onChange={(e) => setDescription(e.target.value)} disabled={busy} />
        </Field>
        <Field
          label={lesson ? 'Remplacer la vidéo (facultatif)' : 'Vidéo'}
          hint={
            lesson?.videoName
              ? `Vidéo actuelle : ${lesson.videoName}. Remplacer la vidéo remet à zéro la lecture des apprenants qui n’ont pas encore validé la leçon.`
              : 'Formats acceptés : MP4 (H.264/AAC recommandé) ou WebM.'
          }
        >
          <input
            className="input"
            type="file"
            accept="video/mp4,video/webm"
            required={!lesson}
            disabled={busy}
            onChange={(e) => onFile(e.target.files?.[0] ?? null)}
          />
        </Field>
        {file && (
          <p className="small muted">
            {file.name} · {formatSize(file.size)}
            {duration ? ` · durée ${formatDuration(duration)}` : ''}
          </p>
        )}
        {unreadable && (
          <Alert kind="warn">Votre navigateur n’a pas pu lire cette vidéo. Vérifiez qu’elle est bien encodée en H.264/AAC (MP4) ou en WebM, sinon les apprenants ne pourront peut-être pas la lire.</Alert>
        )}
        {progress !== null && (
          <div style={{ marginBottom: 14 }}>
            <ProgressBar value={progress} label="Envoi de la vidéo" />
            <div className="small muted">{progress < 100 ? `Envoi en cours… ${progress} %` : 'Enregistrement sur le serveur…'}</div>
          </div>
        )}
        <div className="row" style={{ justifyContent: 'flex-end' }}>
          <button type="button" className="btn" onClick={onClose} disabled={busy}>
            Annuler
          </button>
          <button className="btn btn-primary" disabled={busy}>
            {busy ? 'Envoi…' : 'Enregistrer'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
