import { useState } from 'react';
import { api } from '../../../api';
import { Alert, Modal } from '../../../components/ui';
import { EditorLesson, EditorOption, EditorQuestion } from '../../../types';

const blankQuestion = (): EditorQuestion => ({
  text: '',
  multiple: false,
  options: [
    { text: '', correct: true },
    { text: '', correct: false },
  ],
});

export default function QuizEditor({ lesson, onClose, onSaved }: { lesson: EditorLesson; onClose: () => void; onSaved: () => void }) {
  const [questions, setQuestions] = useState<EditorQuestion[]>(() =>
    lesson.questions.length ? lesson.questions.map((q) => ({ ...q, options: q.options.map((o) => ({ ...o })) })) : [blankQuestion()],
  );
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const patchQuestion = (qi: number, patch: Partial<EditorQuestion>) => setQuestions((qs) => qs.map((q, i) => (i === qi ? { ...q, ...patch } : q)));

  function setMultiple(qi: number, multiple: boolean) {
    setQuestions((qs) =>
      qs.map((q, i) => {
        if (i !== qi) return q;
        if (multiple) return { ...q, multiple };
        // Retour au choix unique : on ne garde que la première bonne réponse
        let kept = false;
        return { ...q, multiple, options: q.options.map((o) => (o.correct && !kept ? ((kept = true), o) : { ...o, correct: false })) };
      }),
    );
  }

  function patchOption(qi: number, oi: number, patch: Partial<EditorOption>) {
    setQuestions((qs) =>
      qs.map((q, i) => {
        if (i !== qi) return q;
        return {
          ...q,
          options: q.options.map((o, j) => {
            if (j === oi) return { ...o, ...patch };
            // En choix unique, cocher une réponse décoche les autres
            if (!q.multiple && patch.correct) return { ...o, correct: false };
            return o;
          }),
        };
      }),
    );
  }

  const addOption = (qi: number) => setQuestions((qs) => qs.map((q, i) => (i === qi && q.options.length < 8 ? { ...q, options: [...q.options, { text: '', correct: false }] } : q)));
  const removeOption = (qi: number, oi: number) =>
    setQuestions((qs) => qs.map((q, i) => (i === qi && q.options.length > 2 ? { ...q, options: q.options.filter((_, j) => j !== oi) } : q)));
  const removeQuestion = (qi: number) => setQuestions((qs) => qs.filter((_, i) => i !== qi));
  const moveQuestion = (qi: number, dir: -1 | 1) =>
    setQuestions((qs) => {
      const j = qi + dir;
      if (j < 0 || j >= qs.length) return qs;
      const copy = [...qs];
      [copy[qi], copy[j]] = [copy[j], copy[qi]];
      return copy;
    });

  function validate(): string | null {
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.text.trim()) return `Question ${i + 1} : l’intitulé est vide.`;
      if (q.options.some((o) => !o.text.trim())) return `Question ${i + 1} : une réponse est vide.`;
      if (!q.options.some((o) => o.correct)) return `Question ${i + 1} : cochez au moins une bonne réponse.`;
    }
    return null;
  }

  async function save() {
    const problem = validate();
    if (problem) return setError(problem);
    setBusy(true);
    setError(null);
    try {
      await api.put(`/lessons/${lesson.id}/quiz`, {
        questions: questions.map((q) => ({ text: q.text, multiple: q.multiple, options: q.options.map((o) => ({ text: o.text, correct: o.correct })) })),
      });
      onSaved();
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }

  return (
    <Modal
      title={`Quiz — ${lesson.title}`}
      wide
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose} disabled={busy}>
            Annuler
          </button>
          <button className="btn btn-primary" onClick={save} disabled={busy}>
            {busy ? 'Enregistrement…' : 'Enregistrer le quiz'}
          </button>
        </>
      }
    >
      {error && <Alert>{error}</Alert>}
      <p className="small muted">Ce quiz s’affiche à l’apprenant une fois la vidéo terminée. Il doit être réussi pour débloquer la leçon suivante.</p>

      {questions.map((q, qi) => (
        <div className="q-card" key={qi}>
          <div className="row row-between" style={{ marginBottom: 8 }}>
            <strong>Question {qi + 1}</strong>
            <div className="row" style={{ gap: 2 }}>
              <button className="icon-btn" onClick={() => moveQuestion(qi, -1)} disabled={qi === 0} aria-label="Monter" title="Monter">
                ↑
              </button>
              <button className="icon-btn" onClick={() => moveQuestion(qi, 1)} disabled={qi === questions.length - 1} aria-label="Descendre" title="Descendre">
                ↓
              </button>
              <button className="icon-btn" onClick={() => removeQuestion(qi)} aria-label="Supprimer la question" title="Supprimer la question">
                🗑
              </button>
            </div>
          </div>
          <textarea className="input" rows={2} placeholder="Intitulé de la question" value={q.text} onChange={(e) => patchQuestion(qi, { text: e.target.value })} />
          <div className="row" style={{ margin: '10px 0' }}>
            <label className="row small" style={{ gap: 6 }}>
              <input type="checkbox" checked={q.multiple} onChange={(e) => setMultiple(qi, e.target.checked)} />
              Plusieurs bonnes réponses possibles
            </label>
          </div>
          {q.options.map((o, oi) => (
            <div className="q-option" key={oi}>
              <input
                type={q.multiple ? 'checkbox' : 'radio'}
                name={`correct-${qi}`}
                checked={o.correct}
                onChange={(e) => patchOption(qi, oi, { correct: q.multiple ? e.target.checked : true })}
                title="Bonne réponse"
                aria-label="Bonne réponse"
              />
              <input className="input" placeholder={`Réponse ${oi + 1}`} value={o.text} onChange={(e) => patchOption(qi, oi, { text: e.target.value })} />
              <button className="icon-btn" onClick={() => removeOption(qi, oi)} disabled={q.options.length <= 2} aria-label="Supprimer la réponse">
                ✕
              </button>
            </div>
          ))}
          <button className="btn btn-sm" onClick={() => addOption(qi)} disabled={q.options.length >= 8}>
            + Ajouter une réponse
          </button>
          <div className="field-hint">{q.multiple ? 'Cochez toutes les bonnes réponses : l’apprenant doit toutes les sélectionner.' : 'Sélectionnez la bonne réponse (le bouton rond).'}</div>
        </div>
      ))}
      <button className="btn" onClick={() => setQuestions((qs) => [...qs, blankQuestion()])} disabled={questions.length >= 50}>
        + Ajouter une question
      </button>
    </Modal>
  );
}
