import { api } from '../../../api';
import { Alert, Badge, Empty, ProgressBar, Spinner } from '../../../components/ui';
import { formatDate, useLoad } from '../../../hooks';
import { TrackingRow, TrackingStatus } from '../../../types';

const STATUS: Record<TrackingStatus, ['grey' | 'amber' | 'green', string]> = {
  NOT_STARTED: ['grey', 'Non commencée'],
  IN_PROGRESS: ['amber', 'En cours'],
  COMPLETED: ['green', 'Terminée'],
};

export default function Tracking({ courseId }: { courseId: number }) {
  const { data, error, loading, reload } = useLoad(() => api.get<TrackingRow[]>(`/courses/${courseId}/tracking`), [courseId]);

  if (loading && !data) return <Spinner />;
  if (error || !data) return <Alert>{error}</Alert>;

  const completed = data.filter((r) => r.status === 'COMPLETED').length;

  return (
    <>
      <div className="toolbar">
        <strong>
          {completed} / {data.length} terminée{completed > 1 ? 's' : ''}
        </strong>
        <span className="spacer" />
        <button className="btn btn-sm" onClick={reload}>
          Actualiser
        </button>
        <a className="btn btn-sm btn-primary" href={`/api/courses/${courseId}/progress.csv`}>
          Exporter en CSV
        </a>
      </div>
      {data.length === 0 ? (
        <Empty>Aucun apprenant n’est affecté à cette formation.</Empty>
      ) : (
        <div className="card table-wrap" style={{ padding: 0 }}>
          <table className="table">
            <thead>
              <tr>
                <th>Apprenant</th>
                <th>Service</th>
                <th style={{ minWidth: 160 }}>Progression</th>
                <th>Score moyen</th>
                <th>Dernière activité</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {data.map((r) => {
                const pct = r.totalLessons ? Math.round((r.lessonsPassed / r.totalLessons) * 100) : 0;
                const [kind, label] = STATUS[r.status];
                return (
                  <tr key={r.userId}>
                    <td>
                      <strong>
                        {r.firstName} {r.lastName}
                      </strong>
                      <div className="small muted">{r.email}</div>
                    </td>
                    <td>{r.department ?? '—'}</td>
                    <td>
                      <ProgressBar value={pct} label={`${pct} %`} />
                      <div className="small muted">
                        {r.lessonsPassed} / {r.totalLessons} leçons
                      </div>
                    </td>
                    <td>{r.avgScore !== null ? `${r.avgScore} %` : '—'}</td>
                    <td className="nowrap">{formatDate(r.lastActivity)}</td>
                    <td>
                      <Badge kind={kind}>{label}</Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
