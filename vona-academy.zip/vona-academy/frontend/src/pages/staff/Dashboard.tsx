import { Link } from 'react-router-dom';
import { api } from '../../api';
import { Alert, Badge, Empty, Spinner } from '../../components/ui';
import { formatDate, useLoad } from '../../hooks';
import { Stats } from '../../types';

export default function Dashboard({ space }: { space: 'admin' | 'rh' }) {
  const { data, error, loading } = useLoad(() => api.get<Stats>('/stats'), []);
  const rate = data && data.assignments.total ? Math.round((data.assignments.completed / data.assignments.total) * 100) : 0;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>{space === 'admin' ? 'Tableau de bord administrateur' : 'Tableau de bord RH'}</h1>
          <p className="muted">Vue d’ensemble de la plateforme de formation.</p>
        </div>
        <div className="row">
          <Link className="btn btn-primary" to="/rh/courses">
            Gérer les formations
          </Link>
          <Link className="btn" to={space === 'admin' ? '/admin/users' : '/rh/learners'}>
            {space === 'admin' ? 'Gérer les utilisateurs' : 'Gérer les apprenants'}
          </Link>
        </div>
      </div>

      {error && <Alert>{error}</Alert>}
      {loading && !data && <Spinner />}
      {data && (
        <>
          <div className="stat-grid">
            <div className="stat">
              <div className="value">{data.users.LEARNER}</div>
              <div className="label">Apprenants actifs</div>
            </div>
            <div className="stat">
              <div className="value">
                {data.courses.published} <span className="small muted">/ {data.courses.total}</span>
              </div>
              <div className="label">Formations publiées</div>
            </div>
            <div className="stat">
              <div className="value">{data.assignments.total}</div>
              <div className="label">Affectations</div>
            </div>
            <div className="stat">
              <div className="value">{rate} %</div>
              <div className="label">Taux de complétion ({data.assignments.completed} terminées)</div>
            </div>
            {space === 'admin' && (
              <>
                <div className="stat">
                  <div className="value">{data.users.RH}</div>
                  <div className="label">Comptes RH</div>
                </div>
                <div className="stat">
                  <div className="value">{data.users.ADMIN}</div>
                  <div className="label">Administrateurs</div>
                </div>
              </>
            )}
          </div>

          <h2>Derniers quiz passés</h2>
          {data.recent.length === 0 ? (
            <Empty>Aucun quiz n’a encore été passé.</Empty>
          ) : (
            <div className="card table-wrap" style={{ padding: 0 }}>
              <table className="table">
                <thead>
                  <tr>
                    <th>Apprenant</th>
                    <th>Formation / leçon</th>
                    <th>Score</th>
                    <th>Résultat</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recent.map((r, i) => (
                    <tr key={i}>
                      <td>
                        {r.firstName} {r.lastName}
                      </td>
                      <td>
                        {r.courseTitle} <span className="muted">› {r.lessonTitle}</span>
                      </td>
                      <td>{r.score} %</td>
                      <td>{r.passed ? <Badge kind="green">Réussi</Badge> : <Badge kind="red">Échec</Badge>}</td>
                      <td className="nowrap">{formatDate(r.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </>
  );
}
