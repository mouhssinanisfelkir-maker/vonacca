import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../../api';
import { Alert, Badge, Empty, Field, Modal, Spinner } from '../../components/ui';
import { useLoad } from '../../hooks';
import { CourseListItem } from '../../types';

export default function Courses() {
  const navigate = useNavigate();
  const { data, error, loading } = useLoad(() => api.get<CourseListItem[]>('/courses'), []);
  const [creating, setCreating] = useState(false);

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Formations</h1>
          <p className="muted">Créez vos formations (vidéos + quiz) et choisissez les apprenants concernés.</p>
        </div>
        <button className="btn btn-accent" onClick={() => setCreating(true)}>
          + Nouvelle formation
        </button>
      </div>

      {error && <Alert>{error}</Alert>}
      {loading && !data && <Spinner />}
      {data && data.length === 0 && <Empty>Aucune formation pour le moment. Créez la première !</Empty>}
      <div className="grid grid-3">
        {data?.map((c) => (
          <div key={c.id} className="card course-card">
            <div className="row row-between">
              <h3>{c.title}</h3>
              {c.published ? <Badge kind="green">Publiée</Badge> : <Badge kind="grey">Brouillon</Badge>}
            </div>
            <p className="desc">{c.description || 'Aucune description.'}</p>
            <div className="small muted">
              {c.lessonCount} leçon{c.lessonCount > 1 ? 's' : ''} · {c.assignedCount} apprenant{c.assignedCount > 1 ? 's' : ''} · {c.completedCount} terminée{c.completedCount > 1 ? 's' : ''}
            </div>
            <Link className="btn btn-primary" to={`/rh/courses/${c.id}`}>
              Ouvrir
            </Link>
          </div>
        ))}
      </div>

      {creating && (
        <CreateModal
          onClose={() => setCreating(false)}
          onCreated={(id) => navigate(`/rh/courses/${id}`)}
        />
      )}
    </>
  );
}

function CreateModal({ onClose, onCreated }: { onClose: () => void; onCreated: (id: number) => void }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [passScore, setPassScore] = useState(70);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await api.post<{ id: number }>('/courses', { title, description, passScore });
      onCreated(r.id);
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  }

  return (
    <Modal title="Nouvelle formation" onClose={onClose}>
      <form onSubmit={submit}>
        {error && <Alert>{error}</Alert>}
        <Field label="Titre">
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} required autoFocus maxLength={200} />
        </Field>
        <Field label="Description">
          <textarea className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <Field label="Score minimum pour réussir un quiz (%)" hint="L’apprenant doit atteindre ce score pour débloquer la vidéo suivante.">
          <input className="input" type="number" min={1} max={100} value={passScore} onChange={(e) => setPassScore(Number(e.target.value))} required />
        </Field>
        <div className="row" style={{ justifyContent: 'flex-end' }}>
          <button type="button" className="btn" onClick={onClose}>
            Annuler
          </button>
          <button className="btn btn-primary" disabled={busy}>
            {busy ? 'Création…' : 'Créer la formation'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
