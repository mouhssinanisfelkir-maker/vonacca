import { FormEvent, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../../api';
import { Alert, Badge, Empty, Field, Spinner } from '../../components/ui';
import { formatDuration, useLoad } from '../../hooks';
import { EditorCourse, EditorLesson } from '../../types';
import LessonModal from './editor/LessonModal';
import Participants from './editor/Participants';
import QuizEditor from './editor/QuizEditor';
import Tracking from './editor/Tracking';

type Tab = 'content' | 'settings' | 'participants' | 'tracking';

function problemsOf(course: EditorCourse): string[] {
  const p: string[] = [];
  if (course.lessons.length === 0) p.push('Ajoutez au moins une leçon.');
  course.lessons.forEach((l) => {
    if (!l.hasVideo) p.push(`« ${l.title} » : vidéo manquante.`);
    if (l.questions.length === 0) p.push(`« ${l.title} » : le quiz est vide.`);
  });
  return p;
}

export default function CourseEditor() {
  const { courseId } = useParams();
  const { data: course, error, loading, reload } = useLoad(() => api.get<EditorCourse>(`/courses/${courseId}`), [courseId]);
  const [tab, setTab] = useState<Tab>('content');
  const [msg, setMsg] = useState<{ kind: 'error' | 'ok'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function setPublished(published: boolean) {
    setBusy(true);
    setMsg(null);
    try {
      await api.patch(`/courses/${courseId}`, { published });
      setMsg({ kind: 'ok', text: published ? 'Formation publiée : les apprenants affectés peuvent la suivre.' : 'Formation repassée en brouillon.' });
      reload();
    } catch (e) {
      setMsg({ kind: 'error', text: (e as Error).message });
    } finally {
      setBusy(false);
    }
  }

  if (loading && !course) return <Spinner />;
  if (error || !course) return <Alert>{error ?? 'Formation introuvable.'}</Alert>;

  const problems = problemsOf(course);

  return (
    <>
      <Link className="back-link" to="/rh/courses">
        ← Toutes les formations
      </Link>
      <div className="page-head">
        <div>
          <div className="row">
            <h1 style={{ margin: 0 }}>{course.title}</h1>
            {course.published ? <Badge kind="green">Publiée</Badge> : <Badge kind="grey">Brouillon</Badge>}
          </div>
          <p className="muted">{course.lessons.length} leçon{course.lessons.length > 1 ? 's' : ''} · réussite d’un quiz à partir de {course.passScore} %</p>
        </div>
        <div className="row">
          <Link className="btn" to={`/courses/${course.id}`}>
            👁 Aperçu apprenant
          </Link>
          {course.published ? (
            <button className="btn" onClick={() => setPublished(false)} disabled={busy}>
              Repasser en brouillon
            </button>
          ) : (
            <button className="btn btn-accent" onClick={() => setPublished(true)} disabled={busy}>
              Publier la formation
            </button>
          )}
        </div>
      </div>

      {msg && <Alert kind={msg.kind}>{msg.text}</Alert>}
      {problems.length > 0 && (
        <Alert kind="warn">
          {course.published ? 'Cette formation est publiée mais incomplète :' : 'Pour pouvoir publier cette formation :'}
          <ul>
            {problems.map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
        </Alert>
      )}

      <div className="tabs">
        {(
          [
            ['content', 'Contenu (vidéos & quiz)'],
            ['participants', 'Apprenants concernés'],
            ['tracking', 'Suivi'],
            ['settings', 'Paramètres'],
          ] as [Tab, string][]
        ).map(([id, label]) => (
          <button key={id} className={`tab ${tab === id ? 'active' : ''}`} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </div>

      {tab === 'content' && <Content course={course} reload={reload} />}
      {tab === 'participants' && <Participants courseId={course.id} published={course.published} />}
      {tab === 'tracking' && <Tracking courseId={course.id} />}
      {tab === 'settings' && <Settings course={course} reload={reload} />}
    </>
  );
}

function Content({ course, reload }: { course: EditorCourse; reload: () => void }) {
  const [lessonModal, setLessonModal] = useState<EditorLesson | 'new' | null>(null);
  const [quizLesson, setQuizLesson] = useState<EditorLesson | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Garde la fenêtre du quiz synchronisée avec les données rechargées
  useEffect(() => {
    if (quizLesson) setQuizLesson(course.lessons.find((l) => l.id === quizLesson.id) ?? null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [course]);

  async function move(index: number, dir: -1 | 1) {
    const ids = course.lessons.map((l) => l.id);
    const j = index + dir;
    if (j < 0 || j >= ids.length) return;
    [ids[index], ids[j]] = [ids[j], ids[index]];
    setError(null);
    try {
      await api.put(`/courses/${course.id}/lessons/order`, { ids });
      reload();
    } catch (e) {
      setError((e as Error).message);
    }
  }

  async function remove(l: EditorLesson) {
    if (!confirm(`Supprimer la leçon « ${l.title} » (vidéo, quiz et progression associés) ?`)) return;
    setError(null);
    try {
      await api.del(`/lessons/${l.id}`);
      reload();
    } catch (e) {
      setError((e as Error).message);
    }
  }

  return (
    <>
      {error && <Alert>{error}</Alert>}
      <div className="row row-between" style={{ marginBottom: 14 }}>
        <p className="muted" style={{ margin: 0 }}>
          L’apprenant suit les leçons dans l’ordre : après chaque vidéo, il doit réussir le quiz pour accéder à la suivante.
        </p>
        <button className="btn btn-accent" onClick={() => setLessonModal('new')}>
          + Ajouter une leçon
        </button>
      </div>

      {course.lessons.length === 0 && <Empty>Aucune leçon. Ajoutez une première vidéo.</Empty>}
      {course.lessons.map((l, i) => (
        <div className="editor-lesson" key={l.id}>
          <div className="lesson-num">{i + 1}</div>
          <div className="lesson-info" style={{ flex: 1, minWidth: 0 }}>
            <strong>{l.title}</strong>
            <div className="small muted">
              {l.hasVideo ? (
                <>
                  🎬 {l.videoName}
                  {l.durationSeconds ? ` · ${formatDuration(l.durationSeconds)}` : ''}
                </>
              ) : (
                <span style={{ color: 'var(--danger)' }}>Vidéo manquante</span>
              )}
              {' · '}
              {l.questions.length > 0 ? (
                `${l.questions.length} question${l.questions.length > 1 ? 's' : ''}`
              ) : (
                <span style={{ color: 'var(--danger)' }}>Quiz vide</span>
              )}
            </div>
          </div>
          <div className="actions">
            <button className="icon-btn" onClick={() => move(i, -1)} disabled={i === 0} title="Monter" aria-label="Monter">
              ↑
            </button>
            <button className="icon-btn" onClick={() => move(i, 1)} disabled={i === course.lessons.length - 1} title="Descendre" aria-label="Descendre">
              ↓
            </button>
            <button className="btn btn-sm" onClick={() => setQuizLesson(l)}>
              Quiz
            </button>
            <button className="btn btn-sm" onClick={() => setLessonModal(l)}>
              Modifier
            </button>
            <button className="btn btn-sm btn-danger" onClick={() => remove(l)}>
              Supprimer
            </button>
          </div>
        </div>
      ))}

      {lessonModal && (
        <LessonModal
          courseId={course.id}
          lesson={lessonModal === 'new' ? null : lessonModal}
          onClose={() => setLessonModal(null)}
          onSaved={() => {
            setLessonModal(null);
            reload();
          }}
        />
      )}
      {quizLesson && (
        <QuizEditor
          lesson={quizLesson}
          onClose={() => setQuizLesson(null)}
          onSaved={() => {
            setQuizLesson(null);
            reload();
          }}
        />
      )}
    </>
  );
}

function Settings({ course, reload }: { course: EditorCourse; reload: () => void }) {
  const navigate = useNavigate();
  const [title, setTitle] = useState(course.title);
  const [description, setDescription] = useState(course.description);
  const [passScore, setPassScore] = useState(course.passScore);
  const [msg, setMsg] = useState<{ kind: 'error' | 'ok'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      await api.patch(`/courses/${course.id}`, { title, description, passScore });
      setMsg({ kind: 'ok', text: 'Paramètres enregistrés.' });
      reload();
    } catch (err) {
      setMsg({ kind: 'error', text: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!confirm(`Supprimer définitivement la formation « ${course.title} », ses vidéos, ses quiz et toute la progression des apprenants ?`)) return;
    try {
      await api.del(`/courses/${course.id}`);
      navigate('/rh/courses');
    } catch (err) {
      setMsg({ kind: 'error', text: (err as Error).message });
    }
  }

  return (
    <>
      <form className="card" onSubmit={save} style={{ maxWidth: 640 }}>
        {msg && <Alert kind={msg.kind}>{msg.text}</Alert>}
        <Field label="Titre">
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={200} />
        </Field>
        <Field label="Description">
          <textarea className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <Field label="Score minimum pour réussir un quiz (%)" hint="Appliqué à tous les quiz de la formation.">
          <input className="input" type="number" min={1} max={100} value={passScore} onChange={(e) => setPassScore(Number(e.target.value))} required />
        </Field>
        <button className="btn btn-primary" disabled={busy}>
          {busy ? 'Enregistrement…' : 'Enregistrer'}
        </button>
      </form>
      <div className="card" style={{ maxWidth: 640 }}>
        <h3>Zone sensible</h3>
        <p className="muted small">La suppression est définitive : vidéos, quiz et progression de tous les apprenants sont effacés.</p>
        <button className="btn btn-danger" onClick={remove}>
          Supprimer la formation
        </button>
      </div>
    </>
  );
}
