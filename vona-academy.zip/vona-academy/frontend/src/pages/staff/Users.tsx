import { FormEvent, useMemo, useState } from 'react';
import { api } from '../../api';
import { useAuth } from '../../auth';
import { Alert, Badge, Empty, Field, Modal, Spinner } from '../../components/ui';
import { useLoad } from '../../hooks';
import { Role, User } from '../../types';

const ROLE_LABEL: Record<Role, string> = { ADMIN: 'Administrateur', RH: 'RH', LEARNER: 'Apprenant' };

interface Credential {
  email: string;
  name: string;
  password: string;
}

export default function Users({ scope }: { scope: 'admin' | 'rh' }) {
  const { user: me } = useAuth();
  const isAdmin = me?.role === 'ADMIN';
  const { data, error, loading, reload } = useLoad(() => api.get<User[]>('/users'), []);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | Role>('ALL');
  const [editing, setEditing] = useState<User | 'new' | null>(null);
  const [importing, setImporting] = useState(false);
  const [credentials, setCredentials] = useState<Credential[] | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // La page « Apprenants » ne montre que les apprenants, même pour l'admin
  const base = useMemo(() => (data ?? []).filter((u) => scope === 'admin' || u.role === 'LEARNER'), [data, scope]);
  const filtered = base.filter((u) => {
    if (scope === 'admin' && roleFilter !== 'ALL' && u.role !== roleFilter) return false;
    const hay = `${u.firstName} ${u.lastName} ${u.email} ${u.department ?? ''}`.toLowerCase();
    return hay.includes(search.toLowerCase());
  });

  async function toggleActive(u: User) {
    setActionError(null);
    try {
      await api.patch(`/users/${u.id}`, { active: !u.active });
      reload();
    } catch (e) {
      setActionError((e as Error).message);
    }
  }
  async function resetPassword(u: User) {
    if (!confirm(`Réinitialiser le mot de passe de ${u.firstName} ${u.lastName} ?`)) return;
    setActionError(null);
    try {
      const r = await api.patch<{ temporaryPassword?: string }>(`/users/${u.id}`, { resetPassword: true });
      if (r.temporaryPassword) setCredentials([{ email: u.email, name: `${u.firstName} ${u.lastName}`, password: r.temporaryPassword }]);
    } catch (e) {
      setActionError((e as Error).message);
    }
  }
  async function remove(u: User) {
    if (!confirm(`Supprimer définitivement ${u.firstName} ${u.lastName} et tout son historique de formation ?`)) return;
    setActionError(null);
    try {
      await api.del(`/users/${u.id}`);
      reload();
    } catch (e) {
      setActionError((e as Error).message);
    }
  }

  return (
    <>
      <div className="page-head">
        <div>
          <h1>{scope === 'admin' ? 'Utilisateurs' : 'Apprenants'}</h1>
          <p className="muted">
            {scope === 'admin'
              ? 'Gérez les comptes administrateurs, RH et apprenants.'
              : 'Créez les comptes des apprenants avant de les affecter à une formation.'}
          </p>
        </div>
        <div className="row">
          <button className="btn" onClick={() => setImporting(true)}>
            Importer un CSV
          </button>
          <button className="btn btn-accent" onClick={() => setEditing('new')}>
            + Nouvel utilisateur
          </button>
        </div>
      </div>

      <div className="toolbar">
        <input className="input" placeholder="Rechercher (nom, e-mail, service)…" value={search} onChange={(e) => setSearch(e.target.value)} />
        {scope === 'admin' && (
          <select className="input" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value as 'ALL' | Role)}>
            <option value="ALL">Tous les rôles</option>
            <option value="ADMIN">Administrateurs</option>
            <option value="RH">RH</option>
            <option value="LEARNER">Apprenants</option>
          </select>
        )}
        <span className="muted small">{filtered.length} résultat{filtered.length > 1 ? 's' : ''}</span>
      </div>

      {(error || actionError) && <Alert>{error ?? actionError}</Alert>}
      {loading && !data && <Spinner />}
      {data && filtered.length === 0 && <Empty>Aucun utilisateur.</Empty>}
      {filtered.length > 0 && (
        <div className="card table-wrap" style={{ padding: 0 }}>
          <table className="table">
            <thead>
              <tr>
                <th>Nom</th>
                <th>E-mail</th>
                <th>Service</th>
                <th>Rôle</th>
                <th>Statut</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id} className={u.active ? '' : 'inactive'}>
                  <td>
                    <strong>
                      {u.firstName} {u.lastName}
                    </strong>
                  </td>
                  <td>{u.email}</td>
                  <td>{u.department ?? '—'}</td>
                  <td>
                    <Badge kind={u.role === 'ADMIN' ? 'red' : u.role === 'RH' ? 'blue' : 'grey'}>{ROLE_LABEL[u.role]}</Badge>
                  </td>
                  <td>{u.active ? <Badge kind="green">Actif</Badge> : <Badge kind="grey">Désactivé</Badge>}</td>
                  <td>
                    <div className="actions">
                      <button className="btn btn-sm" onClick={() => setEditing(u)}>
                        Modifier
                      </button>
                      {u.id !== me?.id && (
                        <>
                          <button className="btn btn-sm" onClick={() => resetPassword(u)}>
                            Mot de passe
                          </button>
                          <button className="btn btn-sm" onClick={() => toggleActive(u)}>
                            {u.active ? 'Désactiver' : 'Réactiver'}
                          </button>
                        </>
                      )}
                      {isAdmin && u.id !== me?.id && (
                        <button className="btn btn-sm btn-danger" onClick={() => remove(u)}>
                          Supprimer
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <UserModal
          user={editing === 'new' ? null : editing}
          canChooseRole={isAdmin && scope === 'admin'}
          onClose={() => setEditing(null)}
          onSaved={(cred) => {
            setEditing(null);
            reload();
            if (cred) setCredentials([cred]);
          }}
        />
      )}
      {importing && (
        <ImportModal
          onClose={() => setImporting(false)}
          onDone={(creds) => {
            setImporting(false);
            reload();
            if (creds.length) setCredentials(creds);
          }}
        />
      )}
      {credentials && <CredentialsModal credentials={credentials} onClose={() => setCredentials(null)} />}
    </>
  );
}

function UserModal({
  user,
  canChooseRole,
  onClose,
  onSaved,
}: {
  user: User | null;
  canChooseRole: boolean;
  onClose: () => void;
  onSaved: (cred?: Credential) => void;
}) {
  const [firstName, setFirstName] = useState(user?.firstName ?? '');
  const [lastName, setLastName] = useState(user?.lastName ?? '');
  const [email, setEmail] = useState(user?.email ?? '');
  const [department, setDepartment] = useState(user?.department ?? '');
  const [role, setRole] = useState<Role>(user?.role ?? 'LEARNER');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (user) {
        await api.patch(`/users/${user.id}`, { firstName, lastName, department, ...(canChooseRole ? { role } : {}) });
        onSaved();
      } else {
        const r = await api.post<{ temporaryPassword: string }>('/users', { firstName, lastName, email, department, role: canChooseRole ? role : 'LEARNER' });
        onSaved({ email, name: `${firstName} ${lastName}`, password: r.temporaryPassword });
      }
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  }

  return (
    <Modal title={user ? "Modifier l'utilisateur" : 'Nouvel utilisateur'} onClose={onClose}>
      <form onSubmit={submit}>
        {error && <Alert>{error}</Alert>}
        <div className="form-row">
          <Field label="Prénom">
            <input className="input" value={firstName} onChange={(e) => setFirstName(e.target.value)} required autoFocus />
          </Field>
          <Field label="Nom">
            <input className="input" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
          </Field>
        </div>
        <Field label="Adresse e-mail">
          <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required disabled={!!user} />
        </Field>
        <div className="form-row">
          <Field label="Service / département" hint="Sert à filtrer lors de l’affectation aux formations.">
            <input className="input" value={department} onChange={(e) => setDepartment(e.target.value)} placeholder="ex. Commercial" />
          </Field>
          {canChooseRole ? (
            <Field label="Rôle">
              <select className="input" value={role} onChange={(e) => setRole(e.target.value as Role)}>
                <option value="LEARNER">Apprenant</option>
                <option value="RH">RH</option>
                <option value="ADMIN">Administrateur</option>
              </select>
            </Field>
          ) : (
            <Field label="Rôle">
              <input className="input" value="Apprenant" disabled />
            </Field>
          )}
        </div>
        {!user && <p className="small muted">Un mot de passe temporaire sera généré. L’utilisateur devra le changer à sa première connexion.</p>}
        <div className="row" style={{ justifyContent: 'flex-end' }}>
          <button type="button" className="btn" onClick={onClose}>
            Annuler
          </button>
          <button className="btn btn-primary" disabled={busy}>
            {busy ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function CredentialsModal({ credentials, onClose }: { credentials: Credential[]; onClose: () => void }) {
  function download() {
    const csv =
      '﻿' +
      ['Nom;E-mail;Mot de passe temporaire', ...credentials.map((c) => [c.name, c.email, c.password].map((v) => `"${v.replace(/"/g, '""')}"`).join(';'))].join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'identifiants.csv';
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <Modal
      title="Identifiants à transmettre"
      onClose={onClose}
      wide={credentials.length > 1}
      footer={
        <>
          {credentials.length > 1 && (
            <button className="btn" onClick={download}>
              Télécharger (CSV)
            </button>
          )}
          <button className="btn btn-primary" onClick={onClose}>
            Fermer
          </button>
        </>
      }
    >
      <Alert kind="warn">Ces mots de passe temporaires ne seront plus affichés. Transmettez-les maintenant ; ils devront être changés à la première connexion.</Alert>
      {credentials.length === 1 ? (
        <>
          <p>
            <strong>{credentials[0].name}</strong> — {credentials[0].email}
          </p>
          <div className="cred-box">{credentials[0].password}</div>
        </>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Nom</th>
                <th>E-mail</th>
                <th>Mot de passe</th>
              </tr>
            </thead>
            <tbody>
              {credentials.map((c) => (
                <tr key={c.email}>
                  <td>{c.name}</td>
                  <td>{c.email}</td>
                  <td>
                    <code>{c.password}</code>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Modal>
  );
}

// ---------- Import CSV ----------

const normalize = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z]/g, '');

interface ParsedRow {
  email: string;
  firstName: string;
  lastName: string;
  department: string;
  line: number;
  problem?: string;
}

function parseCsv(text: string): { rows: ParsedRow[]; fatal?: string } {
  const lines = text.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) return { rows: [], fatal: 'Le fichier doit contenir une ligne d’en-tête puis au moins un apprenant.' };
  const delim = (lines[0].match(/;/g)?.length ?? 0) >= (lines[0].match(/,/g)?.length ?? 0) ? ';' : ',';
  const split = (l: string) => l.split(delim).map((c) => c.trim().replace(/^"|"$/g, ''));
  const header = split(lines[0]).map(normalize);
  const idx = (names: string[]) => header.findIndex((h) => names.includes(h));
  const iEmail = idx(['email', 'mail', 'courriel', 'adresseemail']);
  const iFirst = idx(['prenom', 'firstname']);
  const iLast = idx(['nom', 'lastname', 'nomdefamille']);
  const iDept = idx(['service', 'departement', 'department']);
  if (iEmail < 0 || iFirst < 0 || iLast < 0) {
    return { rows: [], fatal: 'Colonnes obligatoires introuvables : email, prenom, nom (service est facultatif).' };
  }
  const rows = lines.slice(1).map((l, i): ParsedRow => {
    const c = split(l);
    const row: ParsedRow = {
      email: (c[iEmail] ?? '').toLowerCase(),
      firstName: c[iFirst] ?? '',
      lastName: c[iLast] ?? '',
      department: iDept >= 0 ? (c[iDept] ?? '') : '',
      line: i + 2,
    };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)) row.problem = 'e-mail invalide';
    else if (!row.firstName || !row.lastName) row.problem = 'nom ou prénom manquant';
    return row;
  });
  return { rows };
}

function ImportModal({ onClose, onDone }: { onClose: () => void; onDone: (creds: Credential[]) => void }) {
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [skipped, setSkipped] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const parsed = useMemo(() => (text.trim() ? parseCsv(text) : null), [text]);
  const valid = parsed?.rows.filter((r) => !r.problem) ?? [];
  const invalid = parsed?.rows.filter((r) => r.problem) ?? [];

  async function onFile(file?: File) {
    if (file) setText(await file.text());
  }

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      const r = await api.post<{
        created: { email: string; firstName: string; lastName: string; temporaryPassword: string }[];
        skipped: string[];
      }>('/users/import', { rows: valid.map(({ email, firstName, lastName, department }) => ({ email, firstName, lastName, department })) });
      const creds = r.created.map((c) => ({ email: c.email, name: `${c.firstName} ${c.lastName}`, password: c.temporaryPassword }));
      if (r.skipped.length) {
        setSkipped(r.skipped);
        if (!creds.length) {
          setError('Tous les comptes existent déjà : aucun apprenant créé.');
          setBusy(false);
          return;
        }
      }
      onDone(creds);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }

  return (
    <Modal
      title="Importer des apprenants (CSV)"
      wide
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>
            Annuler
          </button>
          <button className="btn btn-primary" onClick={submit} disabled={busy || valid.length === 0}>
            {busy ? 'Import…' : `Importer ${valid.length} apprenant${valid.length > 1 ? 's' : ''}`}
          </button>
        </>
      }
    >
      <p className="small muted">
        Colonnes attendues : <code>email;prenom;nom;service</code> (la colonne service est facultative, séparateur « ; » ou « , », 200 lignes maximum). Collez le contenu ou choisissez un fichier.
      </p>
      <input type="file" accept=".csv,text/csv,text/plain" onChange={(e) => onFile(e.target.files?.[0])} style={{ marginBottom: 10 }} />
      <textarea
        className="input"
        rows={7}
        placeholder={'email;prenom;nom;service\nmarie.durand@vona.fr;Marie;Durand;Commercial'}
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      {parsed?.fatal && <Alert>{parsed.fatal}</Alert>}
      {parsed && !parsed.fatal && (
        <div style={{ marginTop: 12 }}>
          <Alert kind={valid.length ? 'ok' : 'warn'}>
            {valid.length} ligne{valid.length > 1 ? 's' : ''} valide{valid.length > 1 ? 's' : ''}
            {invalid.length > 0 && ` · ${invalid.length} ignorée${invalid.length > 1 ? 's' : ''}`}
          </Alert>
          {invalid.length > 0 && (
            <ul className="small muted">
              {invalid.slice(0, 8).map((r) => (
                <li key={r.line}>
                  Ligne {r.line} : {r.problem}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
      {skipped.length > 0 && <Alert kind="warn">Déjà existants (ignorés) : {skipped.join(', ')}</Alert>}
      {error && <Alert>{error}</Alert>}
    </Modal>
  );
}
