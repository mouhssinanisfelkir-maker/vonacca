import { Link } from 'react-router-dom';
import { api } from '../../api';
import { Alert, Badge, Empty, ProgressBar, Spinner } from '../../components/ui';
import { useAuth } from '../../auth';
import { useLoad } from '../../hooks';
import { LearnerCourse } from '../../types';

export default function MyCourses() {
  const { user } = useAuth();
  const { data, error, loading } = useLoad(() => api.get<LearnerCourse[]>('/learn/courses'), []);

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Bonjour {user?.firstName} 👋</h1>
          <p className="muted">Retrouvez ici les formations qui vous ont été attribuées.</p>
        </div>
      </div>
      {error && <Alert>{error}</Alert>}
      {loading && !data && <Spinner />}
      {data && data.length === 0 && <Empty>Aucune formation ne vous est attribuée pour le moment.</Empty>}
      <div className="grid grid-3">
        {data?.map((c) => {
          const pct = c.lessonCount ? Math.round((c.passedCount / c.lessonCount) * 100) : 0;
          const finished = c.lessonCount > 0 && c.passedCount === c.lessonCount;
          return (
            <div key={c.id} className="card course-card">
              <div className="row row-between">
                <h3>{c.title}</h3>
                {finished ? <Badge kind="green">Terminée</Badge> : c.passedCount > 0 ? <Badge kind="amber">En cours</Badge> : <Badge kind="blue">À commencer</Badge>}
              </div>
              <p className="desc">{c.description || 'Aucune description.'}</p>
              <div>
                <div className={finished ? 'progress-done' : ''}>
                  <ProgressBar value={pct} label={`Progression : ${pct} %`} />
                </div>
                <div className="small muted" style={{ marginTop: 4 }}>
                  {c.passedCount} / {c.lessonCount} leçon{c.lessonCount > 1 ? 's' : ''} validée{c.passedCount > 1 ? 's' : ''}
                </div>
              </div>
              <Link
                className={`btn ${finished ? '' : 'btn-primary'}`}
                to={!finished && c.nextLessonId ? `/courses/${c.id}/lessons/${c.nextLessonId}` : `/courses/${c.id}`}
              >
                {finished ? 'Revoir la formation' : c.passedCount > 0 ? 'Continuer' : 'Commencer'}
              </Link>
            </div>
          );
        })}
      </div>
    </>
  );
}
