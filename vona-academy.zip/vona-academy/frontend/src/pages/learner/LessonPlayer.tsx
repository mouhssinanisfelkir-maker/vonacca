import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../../api';
import { Alert, Badge, Spinner } from '../../components/ui';
import { useLoad } from '../../hooks';
import { LessonDetail, QuizQuestion, QuizResult } from '../../types';

export default function LessonPlayer() {
  const { courseId, lessonId } = useParams();
  const { data: lesson, error, loading, reload } = useLoad(() => api.get<LessonDetail>(`/learn/lessons/${lessonId}`), [lessonId]);

  if (loading && lesson?.id !== Number(lessonId)) return <Spinner />;
  if (error || !lesson) {
    return (
      <>
        <Link className="back-link" to={`/courses/${courseId}`}>
          ← Retour à la formation
        </Link>
        <Alert>{error ?? 'Leçon introuvable.'}</Alert>
      </>
    );
  }
  return <Player key={lesson.id} lesson={lesson} courseId={courseId!} reload={reload} />;
}

function Player({ lesson, courseId, reload }: { lesson: LessonDetail; courseId: string; reload: () => void }) {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoError, setVideoError] = useState(false);

  // Tant que la vidéo n'est pas validée, on interdit d'avancer au-delà de ce qui a déjà été regardé.
  const trackingRef = useRef(!lesson.preview && !lesson.videoCompleted);
  const maxAllowed = useRef(trackingRef.current ? lesson.maxPosition : Infinity);
  const durationRef = useRef(lesson.durationSeconds ?? 0);
  const sendingRef = useRef(false);

  useEffect(() => {
    trackingRef.current = !lesson.preview && !lesson.videoCompleted;
    if (!trackingRef.current) maxAllowed.current = Infinity;
  }, [lesson.preview, lesson.videoCompleted]);

  const send = useCallback(
    async (ended = false) => {
      if (!trackingRef.current) return;
      if (!ended && sendingRef.current) return;
      sendingRef.current = true;
      try {
        const duration = durationRef.current;
        const r = await api.post<{ videoCompleted: boolean }>(`/learn/lessons/${lesson.id}/progress`, {
          position: ended ? duration : maxAllowed.current,
          duration,
          ended,
        });
        if (r.videoCompleted) {
          trackingRef.current = false;
          maxAllowed.current = Infinity;
          reload(); // fait apparaître le quiz
        }
      } catch {
        /* le prochain battement réessaiera */
      } finally {
        sendingRef.current = false;
      }
    },
    [lesson.id, reload],
  );
  const sendRef = useRef(send);
  sendRef.current = send;

  useEffect(() => {
    const id = setInterval(() => {
      const v = videoRef.current;
      if (v && !v.paused && !v.ended) sendRef.current(false);
    }, 5000);
    return () => {
      clearInterval(id);
      sendRef.current(false); // dernière position en quittant la page
    };
  }, []);

  function onLoadedMetadata() {
    const v = videoRef.current!;
    durationRef.current = v.duration || durationRef.current;
    const resume = maxAllowed.current;
    if (Number.isFinite(resume) && resume > 1 && resume < v.duration - 1) v.currentTime = resume;
  }
  function onTimeUpdate() {
    const v = videoRef.current!;
    if (Number.isFinite(maxAllowed.current) && !v.seeking && v.currentTime > maxAllowed.current && v.currentTime - maxAllowed.current < 3) {
      maxAllowed.current = v.currentTime;
    }
  }
  function onSeeking() {
    const v = videoRef.current!;
    if (v.currentTime > maxAllowed.current + 0.5) v.currentTime = maxAllowed.current;
  }
  function onRateChange() {
    const v = videoRef.current!;
    if (v.playbackRate > 2) v.playbackRate = 2;
  }

  const locked = !lesson.videoCompleted;

  return (
    <>
      <Link className="back-link" to={`/courses/${courseId}`}>
        ← {lesson.courseTitle}
      </Link>
      {lesson.preview && <Alert kind="info">Mode aperçu : rien n’est enregistré et la lecture est libre.</Alert>}
      <div className="page-head">
        <div>
          <h1>{lesson.title}</h1>
          {lesson.description && <p className="muted">{lesson.description}</p>}
        </div>
        {lesson.passed && <Badge kind="green">Leçon validée{lesson.bestScore !== null ? ` · ${lesson.bestScore} %` : ''}</Badge>}
      </div>

      <div className="player-layout">
        {lesson.videoUrl && !videoError ? (
          <div className="video-box">
            <video
              ref={videoRef}
              src={lesson.videoUrl}
              controls
              controlsList="nodownload noplaybackrate"
              disablePictureInPicture
              preload="metadata"
              onContextMenu={(e) => e.preventDefault()}
              onLoadedMetadata={onLoadedMetadata}
              onTimeUpdate={onTimeUpdate}
              onSeeking={onSeeking}
              onRateChange={onRateChange}
              onPause={() => send(false)}
              onEnded={() => send(true)}
              onError={() => setVideoError(true)}
            />
          </div>
        ) : (
          <Alert>{videoError ? 'La vidéo n’a pas pu être chargée. Rechargez la page ou contactez le service RH.' : 'Aucune vidéo pour cette leçon.'}</Alert>
        )}

        {locked ? (
          <div className="card">
            <h2>Quiz</h2>
            <p className="muted" style={{ margin: 0 }}>
              🔒 Regardez la vidéo jusqu’au bout pour accéder au quiz. Vous pouvez revenir en arrière, mais pas avancer au-delà de ce que vous avez déjà vu.
            </p>
          </div>
        ) : !lesson.hasQuiz ? (
          <div className="card">
            <Alert kind="ok">Vidéo terminée : cette leçon est validée.</Alert>
            <NextButton lesson={lesson} courseId={courseId} navigate={navigate} />
          </div>
        ) : (
          <Quiz lesson={lesson} courseId={courseId} reload={reload} />
        )}
      </div>
    </>
  );
}

function NextButton({ lesson, courseId, navigate }: { lesson: LessonDetail; courseId: string; navigate: ReturnType<typeof useNavigate> }) {
  if (!lesson.passed && !lesson.preview) return null;
  return lesson.nextLessonId ? (
    <button className="btn btn-primary" onClick={() => navigate(`/courses/${courseId}/lessons/${lesson.nextLessonId}`)}>
      Leçon suivante →
    </button>
  ) : (
    <button className="btn btn-primary" onClick={() => navigate(`/courses/${courseId}`)}>
      Terminer la formation
    </button>
  );
}

function Quiz({ lesson, courseId, reload }: { lesson: LessonDetail; courseId: string; reload: () => void }) {
  const navigate = useNavigate();
  const questions: QuizQuestion[] = lesson.quiz ?? [];
  const [answers, setAnswers] = useState<Record<number, number[]>>({});
  const [result, setResult] = useState<QuizResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function pick(q: QuizQuestion, optionId: number) {
    if (result) return;
    setAnswers((a) => {
      const cur = a[q.id] ?? [];
      if (!q.multiple) return { ...a, [q.id]: [optionId] };
      return { ...a, [q.id]: cur.includes(optionId) ? cur.filter((x) => x !== optionId) : [...cur, optionId] };
    });
  }

  async function submit() {
    const missing = questions.filter((q) => !answers[q.id]?.length).length;
    if (missing) return setError(`Répondez à toutes les questions (${missing} restante${missing > 1 ? 's' : ''}).`);
    setBusy(true);
    setError(null);
    try {
      const r = await api.post<QuizResult>(`/learn/lessons/${lesson.id}/quiz`, { answers });
      setResult(r);
      if (r.recorded) reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  function retry() {
    setAnswers({});
    setResult(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  const correctness = new Map(result?.results.map((r) => [r.questionId, r.correct]));

  return (
    <div className="card">
      <div className="row row-between">
        <h2>Quiz</h2>
        <span className="small muted">Score minimum requis : {lesson.passScore} %</span>
      </div>
      {lesson.passed && !result && (
        <Alert kind="ok">
          Vous avez déjà réussi ce quiz{lesson.bestScore !== null ? ` (meilleur score : ${lesson.bestScore} %)` : ''}. Vous pouvez le refaire ou passer à la suite.
        </Alert>
      )}
      {error && <Alert>{error}</Alert>}

      {questions.map((q, i) => (
        <div className="question" key={q.id}>
          <div className="question-title">
            <span className="mark">{result ? (correctness.get(q.id) ? '✅' : '❌') : `${i + 1}.`}</span>
            <span>
              {q.text} {q.multiple && <span className="small muted">(plusieurs réponses possibles)</span>}
            </span>
          </div>
          {q.options.map((o) => {
            const selected = (answers[q.id] ?? []).includes(o.id);
            return (
              <label key={o.id} className={`option ${selected ? 'selected' : ''}`}>
                <input
                  type={q.multiple ? 'checkbox' : 'radio'}
                  name={`q-${q.id}`}
                  checked={selected}
                  disabled={!!result}
                  onChange={() => pick(q, o.id)}
                />
                <span>{o.text}</span>
              </label>
            );
          })}
        </div>
      ))}

      {!result ? (
        <button className="btn btn-primary" onClick={submit} disabled={busy}>
          {busy ? 'Correction…' : 'Valider mes réponses'}
        </button>
      ) : (
        <>
          <div className={`result-box ${result.passed ? 'pass' : 'fail'}`}>
            <div className="score">{result.score} %</div>
            {result.passed ? (
              <strong>{result.courseCompleted ? 'Bravo, vous avez terminé la formation !' : 'Quiz réussi, la leçon suivante est débloquée.'}</strong>
            ) : (
              <strong>Score insuffisant (minimum {result.passScore} %). Revoyez la vidéo si besoin, puis réessayez.</strong>
            )}
            {!result.recorded && <div className="small">Aperçu : résultat non enregistré.</div>}
          </div>
          <div className="row">
            {result.passed ? (
              result.nextLessonId ? (
                <button className="btn btn-primary" onClick={() => navigate(`/courses/${courseId}/lessons/${result.nextLessonId}`)}>
                  Leçon suivante →
                </button>
              ) : (
                <button className="btn btn-primary" onClick={() => navigate(`/courses/${courseId}`)}>
                  Terminer la formation
                </button>
              )
            ) : (
              <button className="btn btn-primary" onClick={retry}>
                Réessayer le quiz
              </button>
            )}
            {result.passed && (
              <button className="btn" onClick={retry}>
                Refaire le quiz
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
}
