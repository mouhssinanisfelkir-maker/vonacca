import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../../api';
import { Alert, Badge, ProgressBar, Spinner } from '../../components/ui';
import { formatDuration, useLoad } from '../../hooks';
import { LearnerCourseDetail } from '../../types';

export default function CourseView() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { data: course, error, loading } = useLoad(() => api.get<LearnerCourseDetail>(`/learn/courses/${courseId}`), [courseId]);

  if (loading && !course) return <Spinner />;
  if (error || !course) return <Alert>{error ?? 'Formation introuvable.'}</Alert>;

  const done = course.lessons.filter((l) => l.state === 'done').length;
  const pct = course.lessons.length ? Math.round((done / course.lessons.length) * 100) : 0;

  return (
    <>
      <Link className="back-link" to={course.preview ? `/rh/courses/${course.id}` : '/'}>
        ← {course.preview ? "Retour à l'éditeur" : 'Mes formations'}
      </Link>
      {course.preview && <Alert kind="info">Mode aperçu : vous voyez la formation comme un apprenant, mais votre progression n’est pas enregistrée.</Alert>}
      <div className="page-head">
        <div>
          <h1>{course.title}</h1>
          <p className="muted">{course.description}</p>
        </div>
        {!course.preview && (
          <div style={{ minWidth: 220 }}>
            <div className="small muted">
              Progression : {done} / {course.lessons.length}
            </div>
            <ProgressBar value={pct} />
          </div>
        )}
      </div>

      <Alert kind="info">
        Chaque leçon se termine par un quiz. Il faut obtenir au moins <strong>{course.passScore} %</strong> pour débloquer la leçon suivante.
      </Alert>

      <div className="lesson-list">
        {course.lessons.map((l) => (
          <div key={l.id} className={`lesson-row ${l.state}`}>
            <div className="lesson-num">{l.state === 'done' ? '✓' : l.state === 'locked' ? '🔒' : l.position}</div>
            <div className="lesson-info">
              <strong>{l.title}</strong>
              <span className="small muted">
                {l.state === 'locked'
                  ? 'Réussissez le quiz de la leçon précédente pour débloquer cette leçon.'
                  : `${l.durationSeconds ? `Vidéo ${formatDuration(l.durationSeconds)} · ` : ''}${l.questionCount} question${l.questionCount > 1 ? 's' : ''}${
                      l.bestScore !== null ? ` · meilleur score : ${l.bestScore} %` : ''
                    }`}
              </span>
            </div>
            {l.state === 'done' && <Badge kind="green">Validée</Badge>}
            {l.state !== 'locked' ? (
              <button className={`btn btn-sm ${l.state === 'available' ? 'btn-primary' : ''}`} onClick={() => navigate(`/courses/${course.id}/lessons/${l.id}`)}>
                {l.state === 'done' ? 'Revoir' : l.videoCompleted ? 'Passer le quiz' : 'Regarder'}
              </button>
            ) : (
              <Badge kind="grey">Verrouillée</Badge>
            )}
          </div>
        ))}
      </div>
    </>
  );
}
