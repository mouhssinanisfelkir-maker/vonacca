import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';
import { Logo } from './ui';

const SPACE_LABEL = { ADMIN: 'Espace Admin', RH: 'Espace RH', LEARNER: 'Espace apprenant' } as const;

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  if (!user) return null;

  const links =
    user.role === 'ADMIN'
      ? [
          ['/admin', 'Tableau de bord', true],
          ['/admin/users', 'Utilisateurs', false],
          ['/rh/courses', 'Formations', false],
          ['/rh/learners', 'Apprenants', false],
        ]
      : user.role === 'RH'
        ? [
            ['/rh', 'Tableau de bord', true],
            ['/rh/courses', 'Formations', false],
            ['/rh/learners', 'Apprenants', false],
          ]
        : [['/', 'Mes formations', true]];

  return (
    <div className="app">
      <header className="topbar">
        <Logo light />
        <span className="space-tag">{SPACE_LABEL[user.role]}</span>
        <nav className="nav">
          {links.map(([to, label, end]) => (
            <NavLink key={to as string} to={to as string} end={end as boolean}>
              {label as string}
            </NavLink>
          ))}
        </nav>
        <div className="user-menu">
          <span className="who">
            {user.firstName} {user.lastName}
          </span>
          <NavLink to="/password">Mot de passe</NavLink>
          <button
            onClick={async () => {
              await logout();
              navigate('/login');
            }}
          >
            Déconnexion
          </button>
        </div>
      </header>
      <main className="container">
        <Outlet />
      </main>
    </div>
  );
}
