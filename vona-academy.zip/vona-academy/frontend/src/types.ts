export type Role = 'ADMIN' | 'RH' | 'LEARNER';

export interface User {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  department: string | null;
  role: Role;
  active: boolean;
  mustChangePassword: boolean;
}

export interface CourseListItem {
  id: number;
  title: string;
  description: string;
  passScore: number;
  published: boolean;
  createdAt: string;
  lessonCount: number;
  assignedCount: number;
  completedCount: number;
}

export interface EditorOption {
  id?: number;
  text: string;
  correct: boolean;
}
export interface EditorQuestion {
  id?: number;
  text: string;
  multiple: boolean;
  options: EditorOption[];
}
export interface EditorLesson {
  id: number;
  position: number;
  title: string;
  description: string;
  hasVideo: boolean;
  videoName: string | null;
  durationSeconds: number | null;
  questions: EditorQuestion[];
}
export interface EditorCourse {
  id: number;
  title: string;
  description: string;
  passScore: number;
  published: boolean;
  lessons: EditorLesson[];
}

export type TrackingStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED';
export interface TrackingRow {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  department: string | null;
  assignedAt: string;
  lessonsPassed: number;
  totalLessons: number;
  avgScore: number | null;
  attempts: number;
  lastActivity: string | null;
  status: TrackingStatus;
}

export interface Stats {
  users: { ADMIN: number; RH: number; LEARNER: number };
  courses: { total: number; published: number };
  assignments: { total: number; completed: number };
  recent: {
    userId: number;
    firstName: string;
    lastName: string;
    courseTitle: string;
    lessonTitle: string;
    score: number;
    passed: boolean;
    createdAt: string;
  }[];
}

export interface LearnerCourse {
  id: number;
  title: string;
  description: string;
  lessonCount: number;
  passedCount: number;
  nextLessonId: number | null;
}

export type LessonState = 'locked' | 'available' | 'done';
export interface LearnerCourseDetail {
  id: number;
  title: string;
  description: string;
  passScore: number;
  published: boolean;
  preview: boolean;
  lessons: {
    id: number;
    position: number;
    title: string;
    description: string;
    durationSeconds: number | null;
    questionCount: number;
    state: LessonState;
    videoCompleted: boolean;
    attempts: number;
    bestScore: number | null;
  }[];
}

export interface QuizQuestion {
  id: number;
  text: string;
  multiple: boolean;
  options: { id: number; text: string }[];
}
export interface LessonDetail {
  id: number;
  courseId: number;
  courseTitle: string;
  title: string;
  description: string;
  passScore: number;
  preview: boolean;
  videoUrl: string | null;
  durationSeconds: number | null;
  maxPosition: number;
  videoCompleted: boolean;
  passed: boolean;
  bestScore: number | null;
  hasQuiz: boolean;
  quiz: QuizQuestion[] | null;
  nextLessonId: number | null;
}
export interface QuizResult {
  score: number;
  passed: boolean;
  passScore: number;
  results: { questionId: number; correct: boolean }[];
  nextLessonId: number | null;
  courseCompleted: boolean;
  recorded: boolean;
}
